﻿'use client';

import * as React from 'react';
import { useTheme } from 'next-themes';
import { Toaster as Sonner } from 'sonner';

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
 const { theme = 'system' } = useTheme();

 return (
 <Sonner
 theme={theme as ToasterProps['theme']}
 className="group toaster [&_[data-type=success]>[data-icon]]:text-green-500 [&_[data-type=success]_[data-title]]:text-green-600 [&_[data-type=info]_[data-title]]:text-primary-light dark:text-primary-dark [&_[data-type=error]>[data-icon]]:text-red-600 [&_[data-type=error]_[data-title]]:text-red-600"
 toastOptions={{
 classNames: {
 toast:
 'group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg',
 description: 'group-[.toast]:text-muted-foreground',
 actionButton: 'group-[.toast]:rounded-md group-[.toast]:bg-primary group-[.toast]:text-primary-foreground',
 cancelButton:
 'group-[.toast]:rounded-md group-[.toast]:bg-secondary group-[.toast]:text-secondary-foreground',
 },
 }}
 {...props}
 />
 );
};

export { Toaster };
