// ============================================================================
// LOGIN FORM COMPONENT
// ============================================================================
// LOCATION: /frontend/src/components/auth/LoginForm.tsx
// 
// PURPOSE: Handles login form state, validation, and submission
// 
// FEATURES:
// - Email/password fields with validation
// - Password visibility toggle
// - "Remember me" checkbox
// - Form submission handling
// - Error display
// - Loading state
// - Social login buttons
// ============================================================================

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  LogIn,
  Chrome,
  Apple,
  Github,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '@/src/lib/contexts/AuthContext';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface FormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

interface FormErrors {
  email?: string;
  password?: string;
  general?: string;
}

// ============================================================================
// VALIDATION FUNCTIONS
// ============================================================================

const validateEmail = (email: string): boolean => {
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email);
};

const validatePassword = (password: string): boolean => {
  return password.length >= 8;
};

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function LoginForm() {
  const router = useRouter();
  const { login, isLoading: authLoading, user } = useAuth();
  
  // Redirect if already logged in (check user role and redirect to appropriate dashboard)
  useEffect(() => {
    if (user && !authLoading) {
      if (user.role === 'Admin') router.push('/dashboard/admin');
      else if (user.role === 'Guide') router.push('/dashboard/guide');
      else router.push('/dashboard/traveler');
    }
  }, [user, authLoading, router]);

  // ========================================
  // STATE
  // ========================================
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    rememberMe: false
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false); // local loading for button state
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // ========================================
  // HANDLERS
  // ========================================

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleBlur = (field: string) => {
    setTouched(prev => ({ ...prev, [field]: true }));
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (!validatePassword(formData.password)) {
      newErrors.password = 'Password must be at least 8 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    setErrors({}); // clear general errors

    try {
      await login(formData.email, formData.password, formData.rememberMe);
      // login will redirect based on role – no further action needed
    } catch (error: any) {
  console.error('Login error:', error);
  if (error.response) {
    console.log('Response data:', JSON.stringify(error.response.data, null, 2));
    console.log('Response status:', error.response.status);
    console.log('Response headers:', error.response.headers);
  }
  // ... rest of error handling
      // Try to extract error message from backend response
      let message = 'Invalid email or password. Please try again.';
      if (error.response?.data?.message) {
        message = error.response.data.message;
      } else if (error.response?.data?.error) {
        message = error.response.data.error;
      }

      setErrors({ general: message });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = (provider: string) => {
    // For Google OAuth, we need to redirect to the backend's OAuth start endpoint
    if (provider === 'Google') {
      // We'll implement this in a later task
      window.location.href = `${process.env.NEXT_PUBLIC_API_URL}/api/auth/oauth2/google/start?role=Traveler`;
    } else {
      alert(`${provider} login coming in Phase 3`);
    }
  };

  // ========================================
  // RENDER
  // ========================================

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full"
    >
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl p-6 sm:p-8">

        {/* ========================================
            FORM HEADER
            ======================================== */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Sign In
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Don't have an account?{' '}
            <Link
              href="/auth/signup"
              className="font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
            >
              Sign up
            </Link>
          </p>
        </div>

        {/* ========================================
            GENERAL ERROR MESSAGE
            ======================================== */}
        {errors.general && (
          <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700 dark:text-red-300">
              {errors.general}
            </p>
          </div>
        )}

        {/* ========================================
            FORM
            ======================================== */}
        <form onSubmit={handleSubmit} className="space-y-5">

          {/* Email Field */}
          <div className="space-y-1.5">
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                onBlur={() => handleBlur('email')}
                disabled={isLoading}
                placeholder="you@example.com"
                className={`
                  w-full pl-9 pr-3 py-2.5
                  bg-gray-50 dark:bg-gray-800
                  border rounded-lg
                  text-sm text-gray-900 dark:text-white
                  placeholder-gray-500 dark:placeholder-gray-400
                  focus:outline-none focus:ring-2
                  transition-all
                  ${errors.email && touched.email
                    ? 'border-red-500 focus:ring-red-500/20'
                    : 'border-gray-300 dark:border-gray-700 focus:ring-blue-500/20 focus:border-blue-500'
                  }
                  disabled:opacity-50 disabled:cursor-not-allowed
                `}
              />
            </div>
            {errors.email && touched.email && (
              <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                {errors.email}
              </p>
            )}
          </div>

          {/* Password Field */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Password
              </label>
              <Link
                href="/auth/forgot-password"
                className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
              >
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                onBlur={() => handleBlur('password')}
                disabled={isLoading}
                placeholder="••••••••"
                className={`
                  w-full pl-9 pr-10 py-2.5
                  bg-gray-50 dark:bg-gray-800
                  border rounded-lg
                  text-sm text-gray-900 dark:text-white
                  placeholder-gray-500 dark:placeholder-gray-400
                  focus:outline-none focus:ring-2
                  transition-all
                  ${errors.password && touched.password
                    ? 'border-red-500 focus:ring-red-500/20'
                    : 'border-gray-300 dark:border-gray-700 focus:ring-blue-500/20 focus:border-blue-500'
                  }
                  disabled:opacity-50 disabled:cursor-not-allowed
                `}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.password && touched.password && (
              <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                {errors.password}
              </p>
            )}
          </div>

          {/* Remember Me */}
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className="relative flex items-center justify-center">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleChange}
                  className="peer absolute opacity-0 w-4 h-4 cursor-pointer"
                  aria-label="Remember me"
                />
                <div className={`
                  w-4 h-4 border rounded transition-all duration-200 flex items-center justify-center
                  ${formData.rememberMe
                    ? 'bg-blue-600 dark:bg-blue-500 border-blue-600 dark:border-blue-500'
                    : 'bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-700 group-hover:border-gray-400 dark:group-hover:border-gray-600'
                  }
                `}>
                  {formData.rememberMe && (
                    <CheckCircle className="w-3 h-3 text-white" />
                  )}
                </div>
              </div>
              <span className="text-sm text-gray-700 dark:text-gray-300">
                Remember me
              </span>
            </label>

            <Link
              href="/help"
              className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
            >
              Need help?
            </Link>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="
              w-full
              py-3
              bg-gradient-to-r from-blue-600 to-indigo-600
              dark:from-blue-700 dark:to-indigo-700
              text-white font-semibold
              rounded-lg
              hover:from-blue-700 hover:to-indigo-700
              dark:hover:from-blue-800 dark:hover:to-indigo-800
              transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              flex items-center justify-center gap-2
              shadow-lg hover:shadow-xl
            "
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Signing in...</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </>
            )}
          </button>
        </form>

        {/* ========================================
            SOCIAL LOGIN DIVIDER
            ======================================== */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200 dark:border-gray-800" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="px-2 bg-white dark:bg-gray-900 text-gray-500 dark:text-gray-400">
              Or continue with
            </span>
          </div>
        </div>

        {/* ========================================
            SOCIAL LOGIN BUTTONS
            ======================================== */}
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleSocialLogin('Google')}
            disabled={isLoading}
            className="
              p-2.5
              bg-white dark:bg-gray-800
              border border-gray-300 dark:border-gray-700
              rounded-lg
              hover:bg-gray-50 dark:hover:bg-gray-700
              transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              flex items-center justify-center
              group
            "
            aria-label="Sign in with Google"
          >
            <Chrome className="w-5 h-5 text-gray-700 dark:text-gray-300 group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={() => handleSocialLogin('Apple')}
            disabled={isLoading}
            className="
              p-2.5
              bg-white dark:bg-gray-800
              border border-gray-300 dark:border-gray-700
              rounded-lg
              hover:bg-gray-50 dark:hover:bg-gray-700
              transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              flex items-center justify-center
              group
            "
            aria-label="Sign in with Apple"
          >
            <Apple className="w-5 h-5 text-gray-700 dark:text-gray-300 group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={() => handleSocialLogin('GitHub')}
            disabled={isLoading}
            className="
              p-2.5
              bg-white dark:bg-gray-800
              border border-gray-300 dark:border-gray-700
              rounded-lg
              hover:bg-gray-50 dark:hover:bg-gray-700
              transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              flex items-center justify-center
              group
            "
            aria-label="Sign in with GitHub"
          >
            <Github className="w-5 h-5 text-gray-700 dark:text-gray-300 group-hover:scale-110 transition-transform" />
          </button>
        </div>

        {/* Security Note */}
        <p className="text-xs text-center text-gray-500 dark:text-gray-500 mt-6">
          <Lock className="inline w-3 h-3 mr-1" />
          Your credentials are encrypted and secure
        </p>
      </div>
    </motion.div>
  );
}