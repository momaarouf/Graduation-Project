'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { Lock, Eye, EyeOff, CheckCircle, AlertCircle, ArrowRight, Loader2, Shield, ChevronLeft } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import OtpInput from '@/src/components/ui/OtpInput'

const getPasswordStrength = (p: string) => {
  if (!p) return { score: 0, label: '', color: 'bg-gray-200', message: '' }
  const checks = [p.length >= 8, p.length >= 12, /[A-Z]/.test(p), /[0-9]/.test(p), /[^A-Za-z0-9]/.test(p)]
  const s = checks.filter(Boolean).length
  if (s <= 1) return { score: 20, label: 'Weak',      color: 'bg-red-500',     message: 'Add uppercase, numbers & symbols' }
  if (s <= 2) return { score: 40, label: 'Fair',      color: 'bg-orange-500',  message: 'Make it longer' }
  if (s <= 3) return { score: 60, label: 'Good',      color: 'bg-amber-500',   message: 'Getting stronger' }
  if (s <= 4) return { score: 80, label: 'Strong',    color: 'bg-blue-500',    message: 'Almost perfect' }
  return         { score: 100, label: 'Very Strong', color: 'bg-emerald-500', message: 'Excellent' }
}

interface Props { token?: string }

export default function ResetPasswordForm({ token: propToken }: Props) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { resetPassword } = useAuth()

  const emailFromUrl = searchParams.get('email') || ''

  // Guard: if accessed directly without email param (i.e. not from forgot-password flow), redirect
  useEffect(() => {
    if (!emailFromUrl && !propToken) {
      router.replace('/auth/forgot-password')
    }
  }, [emailFromUrl, propToken, router])

  // Step 1: enter code. Step 2: enter new password
  const [step, setStep] = useState<'code' | 'password'>(propToken ? 'password' : 'code')
  const [digits, setDigits] = useState<string[]>(Array(8).fill(''))
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [showCf, setShowCf] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})

  const code = propToken || digits.join('')
  const codeComplete = code.length === 8 && /^\d{8}$/.test(code)
  const strength = getPasswordStrength(password)
  const passwordsMatch = password === confirm

  const handleCodeSubmit = () => {
    if (!codeComplete) { toast.error('Enter all 8 digits'); return }
    setStep('password')
  }

  const handleReset = async () => {
    setTouched({ password: true, confirm: true })
    const errs: Record<string, string> = {}
    if (password.length < 8) errs.password = 'At least 8 characters'
    if (!passwordsMatch) errs.confirm = 'Passwords do not match'
    if (Object.keys(errs).length) { setErrors(errs); return }

    setIsLoading(true)
    try {
      await resetPassword(code, password)
      toast.success('Password reset! Please log in.', { icon: '🔐', duration: 4000 })
      router.push('/auth/login')
    } catch (err: any) {
      const msg = err?.response?.data?.message || 'Failed to reset. Code may have expired.'
      toast.error(msg)
      setErrors({ general: msg })
      // If code is wrong, go back to code step
      if (err?.response?.status === 400 || err?.response?.status === 404) {
        setStep('code')
        setDigits(Array(8).fill(''))
      }
    } finally {
      setIsLoading(false)
    }
  }

  if (step === 'code') {
    return (
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl p-6 sm:p-8 space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/30 rounded-2xl flex items-center justify-center mx-auto">
            <Shield className="w-7 h-7 text-blue-600 dark:text-blue-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Enter reset code</h2>
          {emailFromUrl && (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              We sent an 8-digit code to <span className="font-medium text-gray-700 dark:text-gray-300">{emailFromUrl}</span>
            </p>
          )}
          <p className="text-xs text-gray-400 dark:text-gray-500">Code expires in 15 minutes · Check spam folder</p>
        </div>

        {/* 8-box OTP */}
        <div className="space-y-4">
          <OtpInput length={8} value={digits} onChange={setDigits} autoFocus />
          <p className="text-center text-xs text-gray-400">
            {digits.filter(Boolean).length}/8 digits entered
          </p>
        </div>

        <button
          onClick={handleCodeSubmit}
          disabled={!codeComplete}
          className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-xl hover:from-blue-700 hover:to-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 group transition-all"
        >
          <span>Continue</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
        </button>

        <div className="text-center space-y-2">
          <Link href="/auth/forgot-password" className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
            Resend code
          </Link>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            <Link href="/auth/login" className="hover:underline">Back to login</Link>
          </p>
        </div>
      </div>
    )
  }

  // Step 2: password entry
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl p-6 sm:p-8 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        {!propToken && (
          <button onClick={() => setStep('code')} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 mb-2 transition">
            <ChevronLeft className="w-4 h-4" /> Back to code
          </button>
        )}
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Set new password</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Choose a strong password you haven't used before.</p>
      </div>

      {/* General error */}
      {errors.general && (
        <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-700 dark:text-red-300">{errors.general}</p>
        </div>
      )}

      {/* New password */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">New Password</label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type={showPw ? 'text' : 'password'}
            value={password}
            onChange={e => { setPassword(e.target.value); setErrors(p => ({...p, password: ''})) }}
            onBlur={() => setTouched(p => ({...p, password: true}))}
            disabled={isLoading}
            placeholder="Min. 8 characters"
            className={`w-full pl-9 pr-10 py-3 bg-gray-50 dark:bg-gray-800 border rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 transition-all ${
              errors.password && touched.password ? 'border-red-500 focus:ring-red-500/20'
              : password.length >= 8 ? 'border-emerald-500 focus:ring-emerald-500/20'
              : 'border-gray-300 dark:border-gray-700 focus:ring-blue-500/20 focus:border-blue-500'
            }`}
          />
          <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        {password && (
          <div className="space-y-1 pt-1">
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div className={`h-full ${strength.color} transition-all duration-300`} style={{ width: `${strength.score}%` }} />
              </div>
              {strength.label && <span className="text-xs font-medium text-gray-600 dark:text-gray-400 w-20 text-right">{strength.label}</span>}
            </div>
            <p className="text-xs text-gray-500">{strength.message}</p>
          </div>
        )}
        {errors.password && touched.password && (
          <p className="text-xs text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.password}</p>
        )}
      </div>

      {/* Confirm password */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Confirm Password</label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type={showCf ? 'text' : 'password'}
            value={confirm}
            onChange={e => { setConfirm(e.target.value); setErrors(p => ({...p, confirm: ''})) }}
            onBlur={() => setTouched(p => ({...p, confirm: true}))}
            disabled={isLoading}
            placeholder="Repeat your password"
            className={`w-full pl-9 pr-10 py-3 bg-gray-50 dark:bg-gray-800 border rounded-xl text-sm text-gray-900 dark:text-white focus:outline-none focus:ring-2 transition-all ${
              errors.confirm && touched.confirm ? 'border-red-500 focus:ring-red-500/20'
              : confirm && passwordsMatch ? 'border-emerald-500 focus:ring-emerald-500/20'
              : 'border-gray-300 dark:border-gray-700 focus:ring-blue-500/20 focus:border-blue-500'
            }`}
          />
          <button type="button" onClick={() => setShowCf(!showCf)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            {showCf ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        {errors.confirm && touched.confirm && (
          <p className="text-xs text-red-600 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{errors.confirm}</p>
        )}
        {confirm && passwordsMatch && touched.confirm && (
          <p className="text-xs text-emerald-600 flex items-center gap-1"><CheckCircle className="w-3 h-3" />Passwords match</p>
        )}
      </div>

      <button
        onClick={handleReset}
        disabled={isLoading || password.length < 8 || !passwordsMatch || !confirm}
        className="w-full px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-xl hover:from-blue-700 hover:to-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2 group transition-all"
      >
        {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /><span>Resetting…</span></>
          : <><span>Reset Password</span><ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" /></>}
      </button>

      <p className="text-xs text-center text-gray-400 flex items-center justify-center gap-1">
        <Shield className="w-3 h-3" /> Codes expire in 15 minutes
      </p>
    </div>
  )
}