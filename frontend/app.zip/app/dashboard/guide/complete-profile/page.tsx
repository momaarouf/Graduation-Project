'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ChevronLeft, SkipForward } from 'lucide-react'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import { useSignup, SignupProvider } from '@/src/lib/contexts/SignupContext'
import GuideProfileForm from '@/src/components/auth/GuideProfileForm'
import { guideCompleteProfile } from '@/src/lib/api/auth'
import toast from 'react-hot-toast'
import { LanguageProficiencyLabels } from '@/src/types/auth.types'
import PageLayout from '@/src/components/layout/PageLayout'
import PhoneInput from '@/src/components/ui/PhoneInput'

// ─────────────────────────────────────────────────────────────────────────────
// Inner component — must be inside SignupProvider to use GuideProfileForm
// (GuideProfileForm reads/writes from useSignup() for bio, languages, expertise)
// ─────────────────────────────────────────────────────────────────────────────
function GuideProfileCompletionInner() {
  const router = useRouter()
  const { user } = useAuth()
  const { data } = useSignup()

  // Identity fields — required by backend but not collected by GuideProfileForm
  const [fullName, setFullName] = useState(user?.fullName ?? '')
  const [phoneE164, setPhoneE164] = useState('')
  const [country, setCountry] = useState('')
  const [city, setCity] = useState('')
  const [identityErrors, setIdentityErrors] = useState<Record<string, string>>({})

  const validateIdentity = (): boolean => {
    const errs: Record<string, string> = {}
    if (!fullName.trim() || fullName.trim().length < 2) errs.fullName = 'Full name is required (min 2 chars)'
    if (!phoneE164.trim()) errs.phoneE164 = 'Phone number is required'
    else if (!/^\+[1-9]\d{7,14}$/.test(phoneE164)) errs.phoneE164 = 'Must be E.164 format (e.g., +96170123456)'
    if (!country.trim()) errs.country = 'Country is required'
    if (!city.trim()) errs.city = 'City is required'
    setIdentityErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleNext = async () => {
    if (!validateIdentity()) {
      toast.error('Please fill in all required fields above.')
      return
    }
    try {
      await guideCompleteProfile({
        fullName: fullName.trim(),
        phoneE164: phoneE164.trim(),
        country: country.trim(),
        city: city.trim(),
        bio: data.bio ?? '',
        expertise: data.expertise ?? [],
        languages: (data.languages ?? []).map(l => ({
          name: l.language,
          proficiency: LanguageProficiencyLabels[l.proficiency],
        })),
      })
      toast.success('Profile completed!')
      router.push('/dashboard/guide')
    } catch (err: any) {
      const msg = err?.response?.data?.message ?? 'Failed to save profile. Please try again.'
      toast.error(msg)
    }
  }

  const handleBack = () => router.push('/dashboard/guide')

  const inputClass = (field: string) => `
    w-full px-4 py-2.5
    bg-gray-50 dark:bg-gray-800
    border rounded-lg
    text-sm text-gray-900 dark:text-white
    placeholder-gray-500 dark:placeholder-gray-400
    focus:outline-none focus:ring-2 transition-all
    ${identityErrors[field]
      ? 'border-red-500 focus:ring-red-500/20'
      : 'border-gray-300 dark:border-gray-700 focus:ring-blue-500/20 focus:border-blue-500'}
  `

  return (
    <PageLayout>
      <div className="pt-14 sm:pt-16 min-h-screen bg-gray-50 dark:bg-gray-950 py-10">
        <div className="container-safe mx-auto max-w-2xl px-4">

          {/* Top bar */}
          <div className="flex items-center justify-between mb-6">
            <Link href="/dashboard/guide"
              className="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 transition">
              <ChevronLeft className="w-4 h-4" /> Back to dashboard
            </Link>
            <button
              onClick={() => {
                toast('You can complete your profile later from Settings.', { icon: 'ℹ️' })
                router.push('/dashboard/guide')
              }}
              className="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition"
            >
              <SkipForward className="w-4 h-4" />
              Skip for now
            </button>
          </div>

          {/* Warning */}
          <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-xl text-sm text-amber-800 dark:text-amber-300">
            <strong>Required to accept bookings.</strong> You won't be able to receive tour bookings until your profile is complete and ID is verified.
          </div>

          {/* Name pre-fill notice (Google users) */}
          {user?.fullName && (
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-xl text-sm text-blue-700 dark:text-blue-300">
              Signed in as <strong>{user.fullName}</strong>. Your name is already saved from your Google account.
            </div>
          )}

          {/* ── Identity Fields (required by backend) ── */}
          <div className="mb-6 bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xl p-6 sm:p-8 space-y-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Personal Information</h3>

            {/* Full Name */}
            <div className="space-y-1">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Full Name <span className="text-red-500">*</span>
              </label>
              <input type="text" value={fullName} onChange={e => setFullName(e.target.value)}
                placeholder="Your full name" className={inputClass('fullName')} />
              {identityErrors.fullName && <p className="text-xs text-red-600 dark:text-red-400">{identityErrors.fullName}</p>}
            </div>

            {/* Phone */}
            <PhoneInput
              value={phoneE164}
              onChange={setPhoneE164}
              error={identityErrors.phoneE164}
            />

            {/* Country & City */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Country <span className="text-red-500">*</span>
                </label>
                <input type="text" value={country} onChange={e => setCountry(e.target.value)}
                  placeholder="e.g., Lebanon" className={inputClass('country')} />
                {identityErrors.country && <p className="text-xs text-red-600 dark:text-red-400">{identityErrors.country}</p>}
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  City <span className="text-red-500">*</span>
                </label>
                <input type="text" value={city} onChange={e => setCity(e.target.value)}
                  placeholder="e.g., Beirut" className={inputClass('city')} />
                {identityErrors.city && <p className="text-xs text-red-600 dark:text-red-400">{identityErrors.city}</p>}
              </div>
            </div>
          </div>

          {/* Guide-specific form (bio, languages, expertise) */}
          <GuideProfileForm onNext={handleNext} onBack={handleBack} />
        </div>
      </div>
    </PageLayout>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Page — wraps in SignupProvider so GuideProfileForm can use useSignup()
// ─────────────────────────────────────────────────────────────────────────────
export default function GuideCompleteProfilePage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'Guide')) router.push('/auth/login')
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600" />
      </div>
    )
  }

  return (
    <SignupProvider>
      <GuideProfileCompletionInner />
    </SignupProvider>
  )
}   </SignupProvider >
  )
}