// ============================================================================
// GUIDE VERIFICATION PAGE - LIVE STATUS FROM API
// ============================================================================

'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
    Shield,
    Clock,
    CheckCircle,
    XCircle,
    AlertCircle,
    FileText,
    ChevronRight,
    RefreshCw,
    Home,
    Upload,
    Loader2
} from 'lucide-react'
import PageLayout from '@/src/components/layout/PageLayout'
import apiClient from '@/src/lib/api/client'

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

type VerificationStatus = 'not_submitted' | 'pending' | 'approved' | 'rejected'

interface VerificationData {
    status: VerificationStatus
    documentType?: string | null
    submittedAt?: string | null
    rejectionReason?: string | null
    verifiedAt?: string | null
}

// ============================================================================
// STATUS CARD COMPONENT
// ============================================================================

function StatusCard({ data }: { data: VerificationData }) {
    const statusConfig = {
        not_submitted: {
            icon: Upload,
            color: 'text-gray-600 dark:text-gray-400',
            bgColor: 'bg-gray-50 dark:bg-gray-800/50',
            borderColor: 'border-gray-200 dark:border-gray-700',
            title: 'Not Yet Submitted',
            message: 'You haven\'t submitted verification documents yet.',
            action: 'Submit your documents to start the verification process.'
        },
        pending: {
            icon: Clock,
            color: 'text-amber-600 dark:text-amber-400',
            bgColor: 'bg-amber-50 dark:bg-amber-950/30',
            borderColor: 'border-amber-200 dark:border-amber-800',
            title: 'Verification Pending',
            message: 'Your documents are being reviewed by our team.',
            action: 'Typically takes 24-48 hours.'
        },
        approved: {
            icon: CheckCircle,
            color: 'text-emerald-600 dark:text-emerald-400',
            bgColor: 'bg-emerald-50 dark:bg-emerald-950/30',
            borderColor: 'border-emerald-200 dark:border-emerald-800',
            title: 'Verification Approved',
            message: 'Your identity has been verified successfully!',
            action: 'You can now create tours and start earning.'
        },
        rejected: {
            icon: XCircle,
            color: 'text-red-600 dark:text-red-400',
            bgColor: 'bg-red-50 dark:bg-red-950/30',
            borderColor: 'border-red-200 dark:border-red-800',
            title: 'Verification Failed',
            message: 'We couldn\'t verify your documents.',
            action: 'Please resubmit with clear images.'
        }
    }

    const config = statusConfig[data.status]
    const Icon = config.icon

    return (
        <div className={`p-6 rounded-xl border ${config.bgColor} ${config.borderColor}`}>
            <div className="flex items-start gap-4">
                <div className={`p-3 rounded-full ${config.bgColor} ${config.color}`}>
                    <Icon className="w-6 h-6" />
                </div>
                <div className="flex-1">
                    <h2 className={`text-xl font-bold ${config.color} mb-1`}>
                        {config.title}
                    </h2>
                    <p className="text-gray-700 dark:text-gray-300 mb-2">
                        {config.message}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                        {config.action}
                    </p>
                    {data.submittedAt && (
                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mt-3">
                            <Clock className="w-4 h-4" />
                            <span>Submitted: {new Date(data.submittedAt).toLocaleDateString('en-US', {
                                month: 'long', day: 'numeric', year: 'numeric',
                                hour: 'numeric', minute: '2-digit'
                            })}</span>
                        </div>
                    )}
                    {data.verifiedAt && data.status === 'approved' && (
                        <div className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400 mt-2">
                            <CheckCircle className="w-4 h-4" />
                            <span>Verified: {new Date(data.verifiedAt).toLocaleDateString('en-US', {
                                month: 'long', day: 'numeric', year: 'numeric'
                            })}</span>
                        </div>
                    )}
                    {data.documentType && (
                        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mt-2">
                            <FileText className="w-4 h-4" />
                            <span>Document: {data.documentType === 'NATIONAL_ID' ? 'National ID' : 'Passport'}</span>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}

// ============================================================================
// MAIN PAGE
// ============================================================================

export default function GuideVerificationPage() {
    const router = useRouter()
    const [data, setData] = useState<VerificationData | null>(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState('')

    useEffect(() => {
        const fetchStatus = async () => {
            try {
                const res = await apiClient.get('/api/guide/verification/status')
                setData(res.data)
            } catch (err: any) {
                setError(err?.response?.data?.message ?? 'Failed to load verification status.')
            } finally {
                setLoading(false)
            }
        }
        fetchStatus()
    }, [])

    if (loading) {
        return (
            <PageLayout>
                <div className="pt-14 sm:pt-16 min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                </div>
            </PageLayout>
        )
    }

    if (error || !data) {
        return (
            <PageLayout>
                <div className="pt-14 sm:pt-16 min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
                    <div className="text-center">
                        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                        <p className="text-gray-700 dark:text-gray-300">{error || 'Something went wrong.'}</p>
                        <button onClick={() => window.location.reload()}
                            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                            Retry
                        </button>
                    </div>
                </div>
            </PageLayout>
        )
    }

    return (
        <PageLayout>
            <div className="pt-14 sm:pt-16 min-h-screen bg-gray-50 dark:bg-gray-950">
                <div className="container-safe mx-auto max-w-4xl py-8 sm:py-10">

                    {/* HEADER */}
                    <div className="mb-8">
                        <Link href="/dashboard/guide"
                            className="inline-flex items-center gap-1.5 text-sm text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors mb-4 group">
                            <ChevronRight className="w-4 h-4 rotate-180 group-hover:-translate-x-0.5 transition-transform" />
                            <span>Back to Dashboard</span>
                        </Link>
                        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                            Identity Verification
                        </h1>
                        <p className="text-gray-600 dark:text-gray-400">
                            Help us verify your identity to build trust with travelers
                        </p>
                    </div>

                    {/* STATUS CARD */}
                    <div className="mb-8">
                        <StatusCard data={data} />
                    </div>

                    {/* REJECTION REASON */}
                    {data.status === 'rejected' && data.rejectionReason && (
                        <div className="mb-8 p-6 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl">
                            <div className="flex items-start gap-3">
                                <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                                <div>
                                    <h3 className="font-semibold text-red-800 dark:text-red-300 mb-1">
                                        Rejection Reason
                                    </h3>
                                    <p className="text-red-700 dark:text-red-400 mb-4">
                                        {data.rejectionReason}
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* CTA BUTTONS based on status */}
                    {data.status === 'not_submitted' && (
                        <div className="mb-8 p-6 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl">
                            <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center gap-2">
                                <Upload className="w-5 h-5" />
                                Get Started
                            </h3>
                            <p className="text-sm text-blue-800 dark:text-blue-300 mb-4">
                                Submit your ID documents so our team can verify your identity. This is required before you can create tours.
                            </p>
                            <Link href="/dashboard/guide/verification/submit"
                                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl transition-colors">
                                <Upload className="w-5 h-5" />
                                Submit Documents
                            </Link>
                        </div>
                    )}

                    {data.status === 'rejected' && (
                        <div className="mb-8">
                            <Link href="/dashboard/guide/verification/submit"
                                className="inline-flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl transition-colors">
                                <RefreshCw className="w-5 h-5" />
                                Resubmit Documents
                            </Link>
                        </div>
                    )}

                    {data.status === 'pending' && (
                        <div className="mb-8 p-6 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl">
                            <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center gap-2">
                                <Clock className="w-5 h-5" />
                                What happens next?
                            </h3>
                            <ul className="space-y-2 text-sm text-blue-800 dark:text-blue-300">
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                                    <span>Our team manually reviews your documents (24-48 hours)</span>
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                                    <span>You'll receive an email notification once verified</span>
                                </li>
                                <li className="flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                                    <span>Once verified, you can create tours and start earning</span>
                                </li>
                            </ul>
                        </div>
                    )}

                    {data.status === 'approved' && (
                        <div className="mb-8">
                            <button onClick={() => router.push('/dashboard/guide')}
                                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white font-semibold rounded-xl transition-all shadow-lg hover:shadow-xl">
                                <Home className="w-5 h-5" />
                                Go to Dashboard
                            </button>
                        </div>
                    )}

                    {/* PRIVACY NOTE */}
                    <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg text-center">
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                            <Shield className="inline w-3 h-3 mr-1" />
                            Your documents are encrypted and only used for verification.
                            Never shared with travelers or third parties.
                        </p>
                    </div>
                </div>
            </div>
        </PageLayout>
    )
}