'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import {
 Calendar,
 Clock,
 MapPin,
 ChevronRight,
 Compass,
 Sparkles,
 ArrowRight,
 Search,
 CreditCard,
 Star,
 Trophy,
 Zap
} from 'lucide-react'
import { motion } from 'framer-motion'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import { travelerGetProfile, travelerGetLoyaltyStatus, TravelerProfileResponse, LoyaltyStatusResponse, LoyaltyTierType } from '@/src/lib/api/traveler'
import { getGreeting } from '@/src/lib/greeting'
import OnboardingBannerWrapper from '@/src/components/dashboard/OnboardingBannerWrapper'
import { toast } from 'react-hot-toast'
import { getTravelerBookings } from '@/src/lib/api/tours'
import { BookingResponse } from '@/src/lib/types/tour.types'

// ============================================================================
// LOYALTY TIER CONFIG
// Maps each tier to its brand colors and icon for consistent UI rendering
// ============================================================================

const TIER_CONFIG: Record<LoyaltyTierType, {
 label: string
 icon: string
 badge: string
 text: string
 ring: string
 gradient: string
}> = {
 BRONZE: {
 label: 'Bronze',
 icon: '🥉',
 badge: 'bg-accent-light/20 dark:bg-accent-dark/20 dark:bg-amber-900/40 text-accent-light dark:text-accent-dark dark:text-amber-300',
 text: 'text-accent-light dark:text-accent-dark dark:text-amber-300',
 ring: 'ring-accent-light dark:ring-accent-dark/50',
 gradient: 'from-amber-500 to-orange-500',
 },
 SILVER: {
 label: 'Silver',
 icon: '🥈',
 badge: 'bg-slate-100/60 text-slate-700',
 text: 'text-slate-600',
 ring: 'ring-slate-300/50',
 gradient: 'from-slate-400 to-gray-500',
 },
 GOLD: {
 label: 'Gold',
 icon: '🥇',
 badge: 'bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-300',
 text: 'text-yellow-700 dark:text-yellow-400',
 ring: 'ring-yellow-400/60',
 gradient: 'from-yellow-500 to-amber-400',
 },
}

// ============================================================================
// SHARED COMPONENTS
// ============================================================================

function GlassCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
 return (
 <div className={`surface-card border border-theme rounded-xl ${className}`}>
 {children}
 </div>
 )
}

function StatCard({ icon: Icon, label, value, color }: {
 icon: React.ElementType
 label: string
 value: string | number
 color: 'blue' | 'amber' | 'emerald' | 'purple'
}) {
 const iconColors: Record<string, string> = {
 blue: 'bg-primary-light/10 text-primary-light dark:text-primary-dark',
 amber: 'bg-accent-light/10 text-accent-light dark:text-accent-dark',
 emerald: 'bg-success-green/10 text-success-green',
 purple: 'bg-primary-light/10 text-primary-light dark:text-primary-dark',
 }
 return (
 <GlassCard className="p-6">
 <div className={`p-2.5 rounded-lg ${iconColors[color]} w-fit mb-4`}>
 <Icon className="w-5 h-5" />
 </div>
 <div className="text-3xl font-bold text-theme-primary mb-1">{value}</div>
 <div className="text-xs text-theme-muted">{label}</div>
 </GlassCard>
 )
}

/** Loyalty tier stat card — replaces the plain"Profile Status" card */
function LoyaltyStatCard({ loyalty }: { loyalty: LoyaltyStatusResponse | null }) {
 const tier = (loyalty?.loyaltyTier ?? 'BRONZE') as LoyaltyTierType
 const cfg = TIER_CONFIG[tier]

 return (
 <GlassCard className={`p-6 border-l-4 ${cfg.ring.replace('ring-', 'border-l-').replace('/50', '')}`}>
 <div className="flex items-center justify-between mb-4">
 <div className={`p-2.5 rounded-lg ${cfg.badge} w-fit`}>
 <Trophy className="w-5 h-5" />
 </div>
 <span className={`text-xs font-medium px-2 py-1 rounded-full ${cfg.badge}`}>
 {cfg.icon} {cfg.label}
 </span>
 </div>
 <div>
 <div className={`text-3xl font-bold mb-1 ${cfg.text}`}>
 {loyalty ? `${loyalty.discountPct}% off` : '—'}
 </div>
 <div className="text-xs text-theme-muted">
 Loyalty Tier
 </div>
 {loyalty && loyalty.tripsToNextTier > 0 && (
 <p className="text-xs text-theme-muted mt-1">
 {loyalty.tripsToNextTier} trip{loyalty.tripsToNextTier !== 1 ? 's' : ''} to {loyalty.nextTier ? loyalty.nextTier.charAt(0) + loyalty.nextTier.slice(1).toLowerCase() : ''}
 </p>
 )}
 {loyalty && loyalty.tripsToNextTier === 0 && (
 <p className="text-xs text-yellow-500 mt-1 font-bold">✨ Top tier achieved!</p>
 )}
 </div>
 </GlassCard>
 )
}

/** Sidebar loyalty progress card */
function LoyaltyProgressCard({ loyalty }: { loyalty: LoyaltyStatusResponse | null }) {
 if (!loyalty) return null

 const tier = loyalty.loyaltyTier as LoyaltyTierType
 const cfg = TIER_CONFIG[tier]

 // Compute clean progress percentage within the current tier range.
 // Backend gives us tripsToNextTier so we can derive the target.
 let cleanProgress = 0
 if (tier === 'BRONZE') {
 const target = loyalty.completedTrips + loyalty.tripsToNextTier // = silverMinTrips
 cleanProgress = target > 0 ? Math.min(100, (loyalty.completedTrips / target) * 100) : 0
 } else if (tier === 'SILVER') {
 // Between silverMin (5) and goldMin (silverMin + tripsToNextTier)
 const goldTotal = loyalty.completedTrips + loyalty.tripsToNextTier
 const silverMin = goldTotal - (loyalty.tripsToNextTier > 0 ? goldTotal - loyalty.completedTrips + loyalty.tripsToNextTier : 0)
 // Simplified: 0 tripsToNextTier = 100%, otherwise scale from 5
 cleanProgress = loyalty.tripsToNextTier === 0
 ? 100
 : Math.max(0, Math.min(100, ((loyalty.completedTrips - 5) / (goldTotal - 5)) * 100))
 } else {
 cleanProgress = 100
 }

 return (
 <GlassCard className="p-6">
 <div className="flex items-center gap-3 mb-5">
 <div className={`p-2 rounded-lg ${cfg.badge} w-fit`}>
 <Star className="w-4 h-4" />
 </div>
 <div>
 <h3 className="font-semibold text-theme-primary text-sm">Loyalty Status</h3>
 <p className="text-xs text-theme-muted">{cfg.icon} {cfg.label} Member</p>
 </div>
 </div>

 {/* Progress bar to next tier */}
 {loyalty.tripsToNextTier > 0 && loyalty.nextTier && (
 <div className="mb-4">
 <div className="flex justify-between items-center mb-2">
 <span className="text-xs font-semibold text-theme-muted">{cfg.label}</span>
 <span className={`text-xs font-bold uppercase ${TIER_CONFIG[loyalty.nextTier].text}`}>
 {loyalty.nextTier.charAt(0) + loyalty.nextTier.slice(1).toLowerCase()}
 </span>
 </div>
 <div className="w-full h-2 surface-section rounded-full overflow-hidden">
 <motion.div
 className={`h-full rounded-full bg-gradient-to-r ${cfg.gradient}`}
 initial={{ width: 0 }}
 animate={{ width: `${Math.round(cleanProgress)}%` }}
 transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
 />
 </div>
 <p className="text-xs text-theme-muted mt-2 text-center">
 {loyalty.tripsToNextTier} more trip{loyalty.tripsToNextTier !== 1 ? 's' : ''} to unlock{' '}
 <span className={`font-bold ${TIER_CONFIG[loyalty.nextTier].text}`}>
 {loyalty.nextTierDiscountPct}% discount
 </span>
 </p>
 </div>
 )}

 {loyalty.tripsToNextTier === 0 && (
 <div className="text-center p-3 rounded-xl bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200/50 dark:border-yellow-800/30 mb-4">
 <p className="text-yellow-600 dark:text-yellow-400 font-semibold text-sm">✨ Max Tier Achieved!</p>
 <p className="text-xs text-yellow-500 mt-1">You earn {loyalty.discountPct}% off every booking.</p>
 </div>
 )}

 {/* Stats row */}
 <div className="grid grid-cols-2 gap-3">
 <div className="text-center p-3 surface-section rounded-xl">
 <div className="text-2xl font-bold text-theme-primary">{loyalty.completedTrips}</div>
 <div className="text-xs text-theme-muted mt-0.5">Trips Done</div>
 </div>
 <div className="text-center p-3 surface-section rounded-xl">
 <div className={`text-2xl font-bold ${cfg.text}`}>{loyalty.discountPct}%</div>
 <div className="text-xs text-theme-muted mt-0.5">Your Discount</div>
 </div>
 </div>
 </GlassCard>
 )
}

// ============================================================================
// MAIN DASHBOARD PAGE
// ============================================================================

export default function TravelerDashboardPage() {
 const { user } = useAuth()
 const [profile, setProfile] = useState<TravelerProfileResponse | null>(null)
 const [loyalty, setLoyalty] = useState<LoyaltyStatusResponse | null>(null)
 const [bookings, setBookings] = useState<BookingResponse[]>([])
 const [loading, setLoading] = useState(true)

 useEffect(() => {
 async function fetchData() {
 try {
 const [profileData, loyaltyData, bookingsData] = await Promise.all([
 travelerGetProfile(),
 travelerGetLoyaltyStatus().catch(() => null), // non-critical — don't fail whole page
 getTravelerBookings(),
 ])
 setProfile(profileData)
 setLoyalty(loyaltyData)
 setBookings(bookingsData || [])
 } catch (error) {
 console.error('Failed to fetch dashboard data:', error)
 toast.error('Could not load detailed stats')
 } finally {
 setLoading(false)
 }
 }
 fetchData()
 }, [])

 if (loading) {
 return (
 <div className="min-h-screen flex items-center justify-center surface-section">
 <div className="flex flex-col items-center gap-4">
 <div className="w-12 h-12 border-4 border-primary-light dark:border-primary-dark border-t-transparent rounded-full animate-spin" />
 <p className="text-theme-muted animate-pulse font-medium">Loading your adventure...</p>
 </div>
 </div>
 )
 }

 // Find the first active booking that has a loyalty discount applied
 const discountedBooking = bookings.find(
 (b) =>
 b.tierDiscountAmount &&
 b.tierDiscountAmount > 0 &&
 ['Confirmed', 'InProgress'].includes(b.status as string)
 )

 return (
 <div className="min-h-[calc(100vh-4rem)]">
 {/* Background decorative blobs */}
 <div className="fixed inset-0 pointer-events-none overflow-hidden">
 <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary-light/10 rounded-full blur-[120px]" />
 <div className="absolute bottom-[-10%] left-[-10%] w-[30%] h-[30%] bg-purple-500/10 rounded-full blur-[100px]" />
 </div>

 <div className="relative pt-24 pb-12 px-4 sm:px-6 lg:px-8">
 <div className="max-w-7xl mx-auto">

 <OnboardingBannerWrapper />

 {/* HERO */}
 <div className="mb-10">
 <motion.div
 initial={{ opacity: 0, y: 20 }}
 animate={{ opacity: 1, y: 0 }}
 className="flex flex-col md:flex-row md:items-end justify-between gap-6"
 >
 <div>
 <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary-light/10 text-primary-light dark:text-primary-dark rounded-full text-xs font-bold uppercase tracking-widest mb-4">
 <Sparkles className="w-3 h-3" />
 {getGreeting()}
 </div>
 <h1 className="text-4xl sm:text-5xl font-black text-theme-primary tracking-tight leading-tight">
 Hi, {user?.fullName?.split(' ')[0] || 'Traveler'}! <span className="text-primary-light dark:text-primary-dark">Explore</span> more.
 </h1>
 <p className="mt-2 text-lg text-theme-secondary font-medium">
 Ready for your next trip to {profile?.country || 'Lebanon'}?
 </p>
 </div>
 <div className="flex">
 <Link
 href="/tours"
 className="px-6 py-3 bg-primary-light hover:bg-primary-light-hover text-white rounded-lg font-semibold transition-colors flex items-center gap-2"
 >
 <Search className="w-4 h-4" />
 Find Tours
 </Link>
 </div>
 </motion.div>
 </div>

 {/* STATS GRID */}
 <motion.div
 initial={{ opacity: 0, scale: 0.95 }}
 animate={{ opacity: 1, scale: 1 }}
 transition={{ delay: 0.1 }}
 className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"
 >
 <StatCard icon={Compass} label="Completed Trips" value={profile?.completedTrips || 0} color="blue" />
 <StatCard icon={MapPin} label="Base Location" value={profile?.country || 'Lebanon'} color="amber" />
 {/* Loyalty Tier replaces the plain"Profile Status" card */}
 <LoyaltyStatCard loyalty={loyalty} />
 </motion.div>

 <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
 {/* MAIN CONTENT */}
 <div className="lg:col-span-2 space-y-8">

 {/* PAYMENT ALERT */}
 {bookings.some((b) => b.status === 'PendingPayment') && (
 <div className="p-5 bg-indigo-600 rounded-xl text-white flex flex-col md:flex-row items-center justify-between gap-4">
 <div className="flex items-center gap-4">
 <CreditCard className="w-6 h-6 flex-shrink-0" />
 <div>
 <h3 className="font-semibold mb-0.5">Payment Required</h3>
 <p className="text-indigo-100 text-sm">You have an unpaid booking. Complete payment to secure your spot.</p>
 </div>
 </div>
 <Link
 href="/dashboard/traveler/bookings"
 className="px-5 py-2 bg-white text-indigo-600 rounded-lg font-semibold text-sm hover:bg-indigo-50 transition-colors flex-shrink-0"
 >
 Pay Now
 </Link>
 </div>
 )}

 {/* LOYALTY SAVINGS BANNER — only if a confirmed booking has a tier discount */}
 {discountedBooking && (
 <div className="p-4 bg-amber-500 rounded-xl text-white flex items-center gap-4">
 <Zap className="w-5 h-5 flex-shrink-0" />
 <div>
 <p className="font-semibold text-sm">
 🎉 Loyalty discount applied — you saved ${discountedBooking.tierDiscountAmount?.toFixed(2)} on &ldquo;{discountedBooking.tourTitle}&rdquo;
 </p>
 <p className="text-amber-100 text-xs mt-0.5">
 {loyalty?.loyaltyTier} tier earns you {loyalty?.discountPct}% off every trip.
 </p>
 </div>
 </div>
 )}

 {/* UPCOMING TRIPS */}
 <GlassCard className="p-6">
 <div className="flex items-center justify-between mb-6">
 <div>
 <h2 className="text-xl font-bold text-theme-primary">Upcoming Trips</h2>
 <p className="text-sm text-theme-muted">Your confirmed and pending bookings</p>
 </div>
 <Link href="/dashboard/traveler/bookings" className="text-sm font-bold text-primary-light dark:text-primary-dark hover:text-blue-700 flex items-center gap-1 group">
 View All
 <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
 </Link>
 </div>

 {bookings.filter((b) =>
 ['Confirmed', 'PendingGuide', 'InProgress', 'PendingPayment'].includes(b.status as string)
 ).length > 0 ? (
 <div className="space-y-3">
 {bookings
 .filter((b) => ['Confirmed', 'PendingGuide', 'InProgress', 'PendingPayment'].includes(b.status as string))
 .slice(0, 3)
 .map((booking) => (
 <div
 key={booking.id}
 className="p-4 surface-section border border-theme rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3"
 >
 <div className="flex items-center gap-3">
 <div className="w-10 h-10 bg-primary-light/10 rounded-lg flex items-center justify-center">
 <Calendar className="w-5 h-5 text-primary-light dark:text-primary-dark" />
 </div>
 <div>
 <h4 className="font-bold text-theme-primary">{booking.tourTitle}</h4>
 <div className="flex items-center gap-2 text-sm text-theme-muted font-medium">
 <Clock className="w-4 h-4" />
 {new Date(booking.startTimeUtc).toLocaleDateString()}
 </div>
 </div>
 </div>
 <div className="flex items-center gap-2">
 <span className={`px-2 py-1 rounded-full text-xs font-medium ${
 booking.status === 'Confirmed'
 ? 'bg-success-green/15 text-success-green'
 : booking.status === 'InProgress'
 ? 'bg-primary-light/15 text-primary-light dark:text-primary-dark'
 : booking.status === 'PendingPayment'
 ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400'
 : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
 }`}>
 {booking.status === 'PendingPayment' ? 'Unpaid' : booking.status}
 </span>
 <Link href="/dashboard/traveler/bookings" className="p-1.5 surface-section rounded-lg hover:surface-card transition-colors">
 <ChevronRight className="w-4 h-4" />
 </Link>
 </div>
 </div>
 ))}
 </div>
 ) : (
 <div className="surface-section rounded-xl p-10 text-center border-2 border-dashed border-theme">
 <Calendar className="w-8 h-8 text-theme-muted mx-auto mb-3" />
 <h3 className="font-semibold text-theme-primary mb-2">No upcoming trips yet</h3>
 <p className="text-sm text-theme-muted max-w-xs mx-auto mb-4">
 Browse our curated tours and book your next escape!
 </p>
 <Link
 href="/tours"
 className="inline-flex items-center gap-2 px-4 py-2 surface-card border border-theme rounded-lg text-sm font-medium hover:surface-section transition-colors"
 >
 Explore Tours
 </Link>
 </div>
 )}
 </GlassCard>

 {/* RECENT ACTIVITY */}
 <GlassCard className="p-6">
 <div className="flex items-center gap-3 mb-4">
 <div className="p-2 bg-primary-light/20 dark:bg-primary-dark/20 text-primary-light dark:text-primary-dark rounded-xl">
 <Clock className="w-5 h-5" />
 </div>
 <h3 className="font-bold text-theme-primary">Recent Activity</h3>
 </div>
 <div className="space-y-4">
 {user?.profileCompleted && (
 <div className="flex items-center gap-3">
 <div className="w-2 h-2 rounded-full bg-success-green" />
 <p className="text-sm text-theme-secondary font-medium">Completed your profile setup</p>
 </div>
 )}
 {loyalty && loyalty.completedTrips > 0 && (
 <div className="flex items-center gap-3">
 <div className="w-2 h-2 rounded-full bg-accent-light/10 dark:bg-accent-dark" />
 <p className="text-sm text-theme-secondary font-medium">
 Reached {TIER_CONFIG[loyalty.loyaltyTier].icon} {TIER_CONFIG[loyalty.loyaltyTier].label} loyalty tier
 </p>
 </div>
 )}
 <div className="flex items-center gap-3">
 <div className="w-2 h-2 rounded-full bg-primary-light" />
 <p className="text-sm text-theme-secondary font-medium">Joined SafariHub</p>
 </div>
 </div>
 </GlassCard>
 </div>

 {/* SIDEBAR */}
 <div className="space-y-6">
 <LoyaltyProgressCard loyalty={loyalty} />
 </div>
 </div>
 </div>
 </div>
 </div>
 )
}