'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  Users, Shield, Activity, Ban, Scale, DollarSign,
  Globe, Settings, Loader2, RefreshCw, CheckCircle,
  Clock, AlertTriangle, ArrowRight, TrendingUp
} from 'lucide-react'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import { adminGetPendingVerifications, adminGetUsers, adminGetRejectedVerifications } from '@/src/lib/api/admin'

// ─── Section card definition ──────────────────────────────────────────────────
interface SectionCard {
  title: string
  description: string
  href: string
  icon: React.ElementType
  color: 'blue' | 'amber' | 'purple' | 'red' | 'slate' | 'emerald' | 'indigo' | 'gray'
  live: boolean                          // real backend exists
  stat?: { label: string; value: number | null } // live metric to show
  badge?: number | null                  // alert badge (e.g. pending count)
}

// ─── Color map ────────────────────────────────────────────────────────────────
const COLOR = {
  blue:    { icon: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',    border: 'hover:border-blue-400 dark:hover:border-blue-600',    badge: 'bg-blue-600'    },
  amber:   { icon: 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400',  border: 'hover:border-amber-400 dark:hover:border-amber-600',  badge: 'bg-amber-500'   },
  purple:  { icon: 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400', border: 'hover:border-purple-400 dark:hover:border-purple-600', badge: 'bg-purple-600' },
  red:     { icon: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400',        border: 'hover:border-red-400 dark:hover:border-red-600',        badge: 'bg-red-600'     },
  slate:   { icon: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',   border: 'hover:border-slate-400 dark:hover:border-slate-600',   badge: 'bg-slate-500'   },
  emerald: { icon: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400', border: 'hover:border-emerald-400 dark:hover:border-emerald-600', badge: 'bg-emerald-600' },
  indigo:  { icon: 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400', border: 'hover:border-indigo-400 dark:hover:border-indigo-600', badge: 'bg-indigo-600' },
  gray:    { icon: 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400',       border: 'hover:border-gray-400 dark:hover:border-gray-500',     badge: 'bg-gray-500'    },
}

// ─── Section Card Component ───────────────────────────────────────────────────
function Card({ s }: { s: SectionCard }) {
  const c = COLOR[s.color]
  const Icon = s.icon

  return (
    <Link href={s.href}
      className={`group relative bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-5 flex flex-col gap-4 transition-all duration-200 ${c.border} hover:shadow-md`}>

      {/* Live / Coming soon pill */}
      <div className="absolute top-4 right-4">
        {s.live ? (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded-full">
            <CheckCircle className="w-2.5 h-2.5" /> Live
          </span>
        ) : (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-full">
            <Clock className="w-2.5 h-2.5" /> Soon
          </span>
        )}
      </div>

      {/* Icon + badge */}
      <div className="relative w-fit">
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${c.icon}`}>
          <Icon className="w-5 h-5" />
        </div>
        {s.badge != null && s.badge > 0 && (
          <span className={`absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 ${c.badge} text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse`}>
            {s.badge > 99 ? '99+' : s.badge}
          </span>
        )}
      </div>

      {/* Text */}
      <div className="flex-1">
        <h3 className="font-semibold text-gray-900 dark:text-white text-sm">{s.title}</h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 leading-relaxed">{s.description}</p>
      </div>

      {/* Stat or arrow */}
      <div className="flex items-center justify-between">
        {s.stat ? (
          <div>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {s.stat.value !== null ? s.stat.value.toLocaleString() : '—'}
            </p>
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">{s.stat.label}</p>
          </div>
        ) : (
          <span className="text-xs text-gray-400">Coming next milestone</span>
        )}
        <ArrowRight className="w-4 h-4 text-gray-300 dark:text-gray-600 group-hover:text-gray-600 dark:group-hover:text-gray-300 group-hover:translate-x-0.5 transition-all" />
      </div>
    </Link>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AdminDashboardPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()

  const [pendingCount, setPendingCount]   = useState<number | null>(null)
  const [rejectedCount, setRejectedCount] = useState<number | null>(null)
  const [usersCount, setUsersCount]       = useState<number | null>(null)
  const [isLoading, setIsLoading]         = useState(true)
  const [lastRefresh, setLastRefresh]     = useState<Date>(new Date())

  useEffect(() => {
    if (!authLoading && (!user || user.role !== 'Admin')) router.push('/dashboard')
  }, [user, authLoading, router])

  const load = async () => {
    setIsLoading(true)
    try {
      const [verif, rejected, users] = await Promise.allSettled([
        adminGetPendingVerifications(),
        adminGetRejectedVerifications(),
        adminGetUsers(),
      ])
      if (verif.status === 'fulfilled')     setPendingCount(verif.value.length)
      if (rejected.status === 'fulfilled')  setRejectedCount(rejected.value.length)
      if (users.status === 'fulfilled')     setUsersCount(users.value.users.length)
      setLastRefresh(new Date())
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (!authLoading && user?.role === 'Admin') load()
  }, [user, authLoading])

  // ── Section definitions — every sidebar page, no duplication ──────────────
  const sections: SectionCard[] = [
    {
      title: 'Users',
      description: 'View all platform users. Suspend, ban, deactivate, or reactivate accounts.',
      href: '/dashboard/admin/users',
      icon: Users,
      color: 'blue',
      live: true,
      stat: { label: 'Total Users', value: usersCount },
    },
    {
      title: 'Guide Verifications',
      description: 'Review submitted ID documents. Approve or reject guide identity verifications.',
      href: '/dashboard/admin/verifications',
      icon: Shield,
      color: 'amber',
      live: true,
      stat: { label: 'Pending Review', value: pendingCount },
      badge: (pendingCount ?? 0) + (rejectedCount ?? 0) > 0
        ? (pendingCount ?? 0) + (rejectedCount ?? 0)
        : null,
    },
    {
      title: 'Audit Trail',
      description: 'Full log of every admin action — suspensions, bans, approvals — with timestamps.',
      href: '/dashboard/admin/audit',
      icon: Activity,
      color: 'purple',
      live: true,
    },
    {
      title: 'Disputes',
      description: 'Mediate traveler vs guide disputes over bookings, refunds, and tour quality.',
      href: '/dashboard/admin/disputes',
      icon: Scale,
      color: 'red',
      live: false,
    },
    {
      title: 'Blacklist',
      description: 'Public registry of permanently banned guides. Visible during booking flow.',
      href: '/dashboard/admin/blacklist',
      icon: Ban,
      color: 'slate',
      live: false,
    },
    {
      title: 'Payouts',
      description: 'Process and track guide payouts. Manage payout batches and freeze periods.',
      href: '/dashboard/admin/payouts',
      icon: DollarSign,
      color: 'emerald',
      live: false,
    },
    {
      title: 'Tours',
      description: 'Browse all published tours. Monitor capacity alerts and auto-cancel triggers.',
      href: '/dashboard/admin/tours',
      icon: Globe,
      color: 'indigo',
      live: false,
    },
    {
      title: 'Settings',
      description: 'Platform configuration — fee rates, cancellation windows, feature flags.',
      href: '/dashboard/admin/settings',
      icon: Settings,
      color: 'gray',
      live: false,
    },
  ]

  const liveSections    = sections.filter(s => s.live)
  const comingSections  = sections.filter(s => !s.live)
  const alertCount      = (pendingCount ?? 0) + (rejectedCount ?? 0)

  if (authLoading || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    )
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 dark:bg-gray-950">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-10">

        {/* ── Header ─────────────────────────────────────────────────── */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {user?.email}
              {alertCount > 0 && (
                <span className="ml-2 inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-medium">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {alertCount} item{alertCount > 1 ? 's' : ''} need attention
                </span>
              )}
            </p>
          </div>
          <button onClick={load} disabled={isLoading}
            className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition">
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">
              Updated {lastRefresh.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </button>
        </div>

        {/* ── Live Sections ───────────────────────────────────────────── */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <h2 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">
              Live — backed by real API
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {liveSections.map(s => <Card key={s.href} s={s} />)}
          </div>
        </div>

        {/* ── Divider ─────────────────────────────────────────────────── */}
        <div className="border-t border-dashed border-gray-200 dark:border-gray-800" />

        {/* ── Coming Soon Sections ────────────────────────────────────── */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-4 h-4 text-gray-400" />
            <h2 className="text-sm font-semibold text-gray-400 uppercase tracking-wide">
              Coming — next milestones
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {comingSections.map(s => <Card key={s.href} s={s} />)}
          </div>
        </div>

      </div>
    </div>
  )
}