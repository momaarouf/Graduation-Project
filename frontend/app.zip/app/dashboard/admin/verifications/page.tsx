'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import {
  Shield, CheckCircle, XCircle, Clock, Loader2, RefreshCw,
  X, Check, AlertTriangle, FileText, MapPin, User, Eye, EyeOff
} from 'lucide-react'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import {
  adminGetPendingVerifications, adminGetRejectedVerifications, adminGetVerifiedGuides,
  adminApproveVerification, adminRejectVerification, adminApproveVerificationOverride,
  GuideProfileResponse, VerifiedGuideAdminResponse
} from '@/src/lib/api/admin'
import toast from 'react-hot-toast'

type TabType = 'pending' | 'rejected' | 'verified'

// ─── Document Image Card ──────────────────────────────────────────────────────
function DocImage({ src, label }: { src?: string; label: string }) {
  const [show, setShow] = useState(false)
  if (!src) return null
  return (
    <div className="space-y-1">
      <p className="text-xs font-medium text-gray-500 dark:text-gray-400">{label}</p>
      <div className="relative rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-800 aspect-video">
        {show ? (
          <>
            <img src={src} alt={label} className="w-full h-full object-cover" onError={e => (e.currentTarget.src = '/placeholder.jpg')} />
            <button onClick={() => setShow(false)}
              className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-md">
              <EyeOff className="w-3 h-3" />
            </button>
          </>
        ) : (
          <button onClick={() => setShow(true)}
            className="w-full h-full flex flex-col items-center justify-center gap-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition">
            <Eye className="w-5 h-5" />
            <span className="text-xs">Click to reveal</span>
          </button>
        )}
      </div>
    </div>
  )
}

// ─── Verified Guide Card (read-only, clean design) ───────────────────────────
function VerifiedCard({ v }: { v: VerifiedGuideAdminResponse }) {
  const name = v.fullName || '—'
  const email = v.email || '—'
  const verifiedAt = v.verifiedAtUtc ? new Date(v.verifiedAtUtc) : null
  const initials = name.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase()

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-emerald-200 dark:border-emerald-800/50 overflow-hidden hover:shadow-md transition-shadow">
      {/* Green top accent */}
      <div className="h-1 bg-gradient-to-r from-emerald-400 to-teal-500" />

      <div className="p-5 flex items-start gap-4">
        {/* Avatar */}
        <div className="relative flex-shrink-0">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold text-sm">
            {initials}
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center border-2 border-white dark:border-gray-900">
            <CheckCircle className="w-3 h-3 text-white" />
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="font-semibold text-gray-900 dark:text-white truncate">{name}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{email}</p>
            </div>
            <span className="flex-shrink-0 px-2 py-0.5 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 text-xs rounded-full font-medium">
              Verified
            </span>
          </div>

          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-gray-500 dark:text-gray-400">
            {(v.baseCity || v.baseCountry) && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {[v.baseCity, v.baseCountry].filter(Boolean).join(', ')}
              </span>
            )}
            {verifiedAt && (
              <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                Verified {verifiedAt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
              </span>
            )}
          </div>


        </div>
      </div>
    </div>
  )
}

// ─── Verification Card ────────────────────────────────────────────────────────
function VerificationCard({
  v, tab, onApprove, onReject, onOverride, loading
}: {
  v: GuideProfileResponse
  tab: TabType
  onApprove: (id: number) => void
  onReject: (v: GuideProfileResponse) => void
  onOverride: (v: GuideProfileResponse) => void
  loading: boolean
}) {
  const [expanded, setExpanded] = useState(false)
  const name = v.user?.fullName || '—'
  const email = v.user?.email || '—'
  const docType = v.idDocumentType === 'NATIONAL_ID' ? 'National ID' : v.idDocumentType === 'PASSPORT' ? 'Passport' : '—'

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
      {/* Card Header */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
              {name.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-semibold text-gray-900 dark:text-white">{name}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{email}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {tab === 'pending' && (
              <span className="px-2 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 text-xs rounded-full font-medium flex items-center gap-1">
                <Clock className="w-3 h-3" /> Pending
              </span>
            )}
            {tab === 'rejected' && (
              <span className="px-2 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-xs rounded-full font-medium flex items-center gap-1">
                <XCircle className="w-3 h-3" /> Rejected
              </span>
            )}
            {tab === 'verified' && (
              <span className="px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 text-xs rounded-full font-medium flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Verified
              </span>
            )}
          </div>
        </div>

        {/* Meta info row */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="flex items-center gap-1.5 text-sm text-gray-600 dark:text-gray-400">
            <FileText className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{docType}</span>
          </div>
          {(v.baseCity || v.baseCountry) && (
            <div className="flex items-center gap-1.5 text-sm text-gray-600 dark:text-gray-400">
              <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{[v.baseCity, v.baseCountry].filter(Boolean).join(', ')}</span>
            </div>
          )}
          {v.verificationSubmittedAtUtc && (
            <div className="flex items-center gap-1.5 text-sm text-gray-600 dark:text-gray-400 col-span-2">
              <Clock className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Submitted {new Date(v.verificationSubmittedAtUtc).toLocaleString()}</span>
            </div>
          )}
          {v.idVerifiedAtUtc && (
            <div className="flex items-center gap-1.5 text-sm text-green-600 dark:text-green-400 col-span-2">
              <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Verified {new Date(v.idVerifiedAtUtc).toLocaleString()}</span>
            </div>
          )}
        </div>

        {/* Bio */}
        {v.bio && (
          <p className="mt-3 text-sm text-gray-600 dark:text-gray-400 italic line-clamp-2">"{v.bio}"</p>
        )}

        {/* Rejection reason */}
        {v.verificationRejectedReason && (
          <div className="mt-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-sm text-red-700 dark:text-red-300">
              <strong>Rejection reason:</strong> {v.verificationRejectedReason}
            </p>
          </div>
        )}

        {/* Expand/collapse documents */}
        <button onClick={() => setExpanded(e => !e)}
          className="mt-4 text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1">
          {expanded ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
          {expanded ? 'Hide documents' : 'View documents'}
        </button>
      </div>

      {/* Documents */}
      {expanded && (
        <div className="border-t border-gray-100 dark:border-gray-800 p-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <DocImage src={v.idFrontImage || v.idVerificationImage} label="ID Front" />
            {v.idDocumentType === 'NATIONAL_ID' && <DocImage src={v.idBackImage} label="ID Back" />}
            <DocImage src={v.selfieImage} label="Selfie with ID" />
          </div>
          <p className="text-xs text-gray-400 dark:text-gray-500 mt-3">
            ⚠ Images are blurred by default. Click each to reveal.
          </p>
        </div>
      )}

      {/* Actions */}
      {(tab === 'pending' || tab === 'rejected') && (
        <div className="border-t border-gray-100 dark:border-gray-800 px-5 py-4 bg-gray-50 dark:bg-gray-800/30 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            {tab === 'rejected' && (
              <button onClick={() => onOverride(v)} disabled={loading}
                className="px-3 py-1.5 text-xs font-medium border border-indigo-300 dark:border-indigo-700 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/20 flex items-center gap-1.5 transition">
                <AlertTriangle className="w-3.5 h-3.5" /> Override Approve
              </button>
            )}
          </div>
          <div className="flex items-center gap-2 ml-auto">
            <button onClick={() => onReject(v)} disabled={loading}
              className="px-4 py-1.5 text-sm font-medium border border-red-300 dark:border-red-700 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 flex items-center gap-1.5 transition">
              <X className="w-4 h-4" /> Reject
            </button>
            {tab === 'pending' && (
              <button onClick={() => onApprove(v.id)} disabled={loading}
                className="px-4 py-1.5 text-sm font-medium bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded-lg flex items-center gap-1.5 transition">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Approve
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AdminVerificationsPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()

  const [activeTab, setActiveTab] = useState<TabType>('pending')
  const [verifications, setVerifications] = useState<GuideProfileResponse[]>([])
  const [verifiedList, setVerifiedList] = useState<VerifiedGuideAdminResponse[]>([])
  const [counts, setCounts] = useState({ pending: 0, rejected: 0, verified: 0 })
  const [isLoading, setIsLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)

  // Reject/override modal
  const [rejectModal, setRejectModal] = useState<{ open: boolean; v: GuideProfileResponse | null; isOverride: boolean }>
    ({ open: false, v: null, isOverride: false })
  const [rejectReason, setRejectReason] = useState('')
  const [overrideNote, setOverrideNote] = useState('')

  useEffect(() => {
    if (!authLoading && (!user || user.role !== 'Admin')) router.push('/dashboard')
  }, [user, authLoading, router])

  // Load counts for all tabs on mount
  useEffect(() => {
    loadAllCounts()
  }, [])

  useEffect(() => {
    loadVerifications()
  }, [activeTab])

  const loadAllCounts = async () => {
    try {
      const [p, r, v] = await Promise.allSettled([
        adminGetPendingVerifications(),
        adminGetRejectedVerifications(),
        adminGetVerifiedGuides()
      ])
      setCounts({
        pending: p.status === 'fulfilled' ? p.value.length : 0,
        rejected: r.status === 'fulfilled' ? r.value.length : 0,
        verified: v.status === 'fulfilled' ? (v.value as VerifiedGuideAdminResponse[]).length : 0,
      })
    } catch {}
  }

  const loadVerifications = async () => {
    setIsLoading(true)
    try {
      if (activeTab === 'pending') {
        const data = await adminGetPendingVerifications()
        setVerifications(data || [])
      } else if (activeTab === 'rejected') {
        const data = await adminGetRejectedVerifications()
        setVerifications(data || [])
      } else {
        const data = await adminGetVerifiedGuides()
        setVerifiedList(data || [])
      }
    } catch {
      toast.error('Failed to load verifications')
    } finally {
      setIsLoading(false)
    }
  }

  const reload = () => { loadAllCounts(); loadVerifications() }

  const handleApprove = async (id: number) => {
    setActionLoading(true)
    try {
      await adminApproveVerification(id)
      toast.success('Verification approved ✓')
      reload()
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Approval failed')
    } finally { setActionLoading(false) }
  }

  const openReject = (v: GuideProfileResponse, isOverride = false) => {
    setRejectModal({ open: true, v, isOverride })
    setRejectReason(''); setOverrideNote('')
  }

  const handleRejectSubmit = async () => {
    const { v, isOverride } = rejectModal
    if (!v) return

    if (isOverride) {
      setActionLoading(true)
      try {
        await adminApproveVerificationOverride(v.id, overrideNote || undefined)
        toast.success('Override approval applied ✓')
        setRejectModal({ open: false, v: null, isOverride: false })
        reload()
      } catch (e: any) {
        toast.error(e.response?.data?.message || 'Override failed')
      } finally { setActionLoading(false) }
    } else {
      if (!rejectReason.trim()) { toast.error('Rejection reason is required'); return }
      setActionLoading(true)
      try {
        await adminRejectVerification(v.id, rejectReason.trim())
        toast.success('Verification rejected')
        setRejectModal({ open: false, v: null, isOverride: false })
        reload()
      } catch (e: any) {
        toast.error(e.response?.data?.message || 'Rejection failed')
      } finally { setActionLoading(false) }
    }
  }

  const tabs: { key: TabType; label: string; count: number }[] = [
    { key: 'pending', label: 'Pending', count: counts.pending },
    { key: 'rejected', label: 'Rejected', count: counts.rejected },
    { key: 'verified', label: 'Verified', count: counts.verified },
  ]

  if (authLoading) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  )

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 dark:bg-gray-950">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Shield className="w-6 h-6 text-amber-500" /> Guide Verifications
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
              Review identity documents before guides can accept bookings
            </p>
          </div>
          <button onClick={reload} disabled={isLoading}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition">
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-gray-200 dark:border-gray-700">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition -mb-px ${
                activeTab === t.key
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
              }`}>
              {t.label}
              {t.count > 0 && (
                <span className={`px-1.5 py-0.5 rounded-full text-xs font-bold ${
                  t.key === 'pending' ? 'bg-amber-500 text-white animate-pulse'
                  : t.key === 'rejected' ? 'bg-red-500 text-white'
                  : 'bg-green-500 text-white'
                }`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : activeTab === 'verified' ? (
          verifiedList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-400">
              <Shield className="w-10 h-10 mb-3 opacity-40" />
              <p className="text-sm">No verified guides yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {verifiedList.map(v => (
                <VerifiedCard key={v.guideProfileId} v={v} />
              ))}
            </div>
          )
        ) : verifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <Shield className="w-10 h-10 mb-3 opacity-40" />
            <p className="text-sm">No {activeTab} verifications</p>
          </div>
        ) : (
          <div className="space-y-4">
            {verifications.map(v => (
              <VerificationCard
                key={v.id} v={v} tab={activeTab}
                onApprove={handleApprove}
                onReject={v => openReject(v, false)}
                onOverride={v => openReject(v, true)}
                loading={actionLoading}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── Reject / Override Modal ──────────────────────────────────────── */}
      {rejectModal.open && rejectModal.v && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
                {rejectModal.isOverride
                  ? <><AlertTriangle className="w-5 h-5 text-indigo-500" /> Override Approve</>
                  : <><XCircle className="w-5 h-5 text-red-500" /> Reject Verification</>}
              </h3>
              <button onClick={() => setRejectModal({ open: false, v: null, isOverride: false })}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              For <strong className="text-gray-900 dark:text-white">
                {rejectModal.v.user?.fullName}</strong> ({rejectModal.v.user?.email})
            </p>

            {rejectModal.isOverride ? (
              <>
                <div className="p-3 mb-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-lg">
                  <p className="text-sm text-indigo-700 dark:text-indigo-300">
                    Override approves even if documents are incomplete. Use only when you have verified the guide through another means.
                  </p>
                </div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Note (optional)</label>
                <textarea value={overrideNote} onChange={e => setOverrideNote(e.target.value)}
                  placeholder="Reason for override approval..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-sm resize-none"
                />
              </>
            ) : (
              <>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                  Rejection reason <span className="text-red-500">*</span>
                </label>
                <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)}
                  placeholder="e.g. Image is blurry, document appears expired, name mismatch..."
                  rows={3}
                  className="w-full px-3 py-2 border border-red-200 dark:border-red-800 rounded-lg bg-white dark:bg-gray-800 text-sm resize-none"
                />
                <p className="text-xs text-gray-400 mt-1">The guide will see this reason when checking their verification status.</p>
              </>
            )}

            <div className="flex gap-2 justify-end mt-5">
              <button onClick={() => setRejectModal({ open: false, v: null, isOverride: false })}
                className="px-4 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
                Cancel
              </button>
              <button onClick={handleRejectSubmit}
                disabled={actionLoading || (!rejectModal.isOverride && !rejectReason.trim())}
                className={`px-5 py-2 text-sm font-medium text-white rounded-lg flex items-center gap-2 transition disabled:opacity-50 ${
                  rejectModal.isOverride ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-red-600 hover:bg-red-700'
                }`}>
                {actionLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                {rejectModal.isOverride ? 'Confirm Override' : 'Confirm Reject'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}