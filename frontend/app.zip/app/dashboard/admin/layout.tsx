// ============================================================================
// ADMIN LAYOUT - WITH SIDEBAR NAVIGATION & ROLE PROTECTION
// ============================================================================
// LOCATION: /frontend/src/app/dashboard/admin/layout.tsx
// 
// PURPOSE: Provide consistent navigation between all admin pages and enforce admin role
//
// FEATURES:
// - Collapsible sidebar
// - Navigation links to all admin sections
// - Active page highlighting
// - Mobile responsive (hamburger menu)
// - Role protection (non-admins redirected to dashboard)
// - User info and logout
// ============================================================================

'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import {
  LayoutDashboard,
  Shield,
  Ban,
  Scale,
  DollarSign,
  Globe,
  History,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  User,
  Users,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  Loader2
} from 'lucide-react'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import { adminGetPendingVerifications } from '@/src/lib/api/admin'
import PageLayout from '@/src/components/layout/PageLayout'
import toast from 'react-hot-toast'

// ============================================================================
// NAVIGATION ITEMS
// ============================================================================

const NAV_ITEMS = [
  {
    name: 'Dashboard',
    href: '/dashboard/admin',
    icon: LayoutDashboard,
    color: 'blue'
  },
  {
    name: 'Verifications',
    href: '/dashboard/admin/verifications',
    icon: Shield,
    color: 'amber',
  },
  {
    name: 'Disputes',
    href: '/dashboard/admin/disputes',
    icon: Scale,
    color: 'red',
  },
  {
    name: 'Blacklist',
    href: '/dashboard/admin/blacklist',
    icon: Ban,
    color: 'purple'
  },
  {
    name: 'Payouts',
    href: '/dashboard/admin/payouts',
    icon: DollarSign,
    color: 'emerald'
  },
  {
    name: 'Tours',
    href: '/dashboard/admin/tours',
    icon: Globe,
    color: 'indigo'
  },
  {
    name: 'Audit',
    href: '/dashboard/admin/audit',
    icon: History,
    color: 'gray'
  },
  {
    name: 'Settings',
    href: '/dashboard/admin/settings',
    icon: Settings,
    color: 'gray'
},
]

// ============================================================================
// NAVIGATION ITEM COMPONENT
// ============================================================================

interface NavItemProps {
  item: typeof NAV_ITEMS[0]
  isActive: boolean
  isCollapsed: boolean
  onClick?: () => void
  badgeOverride?: number
}

const NavItem = ({ item, isActive, isCollapsed, onClick, badgeOverride }: NavItemProps) => {
  const Icon = item.icon
  const badge = badgeOverride
  
  const colorClasses = {
    blue: isActive 
      ? 'bg-blue-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-950/30 hover:text-blue-600 dark:hover:text-blue-400',
    amber: isActive 
      ? 'bg-amber-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 hover:text-amber-600 dark:hover:text-amber-400',
    red: isActive 
      ? 'bg-red-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-red-600 dark:hover:text-red-400',
    purple: isActive 
      ? 'bg-purple-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-purple-50 dark:hover:bg-purple-950/30 hover:text-purple-600 dark:hover:text-purple-400',
    emerald: isActive 
      ? 'bg-emerald-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 hover:text-emerald-600 dark:hover:text-emerald-400',
    indigo: isActive 
      ? 'bg-indigo-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 hover:text-indigo-600 dark:hover:text-indigo-400',
    gray: isActive 
      ? 'bg-gray-600 text-white' 
      : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'
  }

  return (
    <Link
      href={item.href}
      onClick={onClick}
      className={`
        relative flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200
        ${colorClasses[item.color as keyof typeof colorClasses]}
        ${isCollapsed ? 'justify-center' : 'justify-start'}
        group
      `}
    >
      <Icon className="w-5 h-5 flex-shrink-0" />
      
      {!isCollapsed && (
        <>
          <span className="text-sm font-medium flex-1">{item.name}</span>
          {badge != null && badge > 0 && (
            <span className="px-1.5 py-0.5 bg-amber-500 text-white text-xs font-bold rounded-full animate-pulse">
              {badge}
            </span>
          )}
        </>
      )}

      {isCollapsed && badge != null && badge > 0 && (
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
          {badge}
        </span>
      )}

      {/* Tooltip for collapsed mode */}
      {isCollapsed && (
        <div className="absolute left-full ml-2 px-2 py-1 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-none">
          {item.name}
          {badge != null && badge > 0 && ` (${badge})`}
        </div>
      )}
    </Link>
  )
}

// ============================================================================
// MAIN LAYOUT
// ============================================================================

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  const router = useRouter()
  const { user, isLoading, logout } = useAuth()
  const [isCollapsed, setIsCollapsed] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [pendingCount, setPendingCount] = useState(0)

  // Check role and redirect if not admin
  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'Admin')) {
      router.push('/dashboard')
    }
  }, [user, isLoading, router])

  // Prevent hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  // Load real pending verification count for sidebar badge
  useEffect(() => {
    if (user?.role === "Admin") {
      adminGetPendingVerifications().then(r => setPendingCount(r?.length ?? 0)).catch(() => {})
    }
  }, [user])

  // Show loading while checking auth and role
  if (!mounted || isLoading || !user || user.role !== 'Admin') {
    return (
      <PageLayout>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      </PageLayout>
    )
  }

  const handleLogout = async () => {
    try {
      await logout()
      toast.success('Logged out successfully')
    } catch (error) {
      toast.error('Logout failed')
      router.push('/auth/login')
    }
  }

  return (
    <PageLayout>
      <div className="pt-14 sm:pt-16 min-h-screen bg-gray-50 dark:bg-gray-950">

        {/* ── Mobile Header with Hamburger ── */}
        <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
          <h1 className="font-bold text-gray-900 dark:text-white">Admin Panel</h1>
          <button
            onClick={() => setIsMobileOpen(true)}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5 text-gray-700 dark:text-gray-300" />
          </button>
        </div>

        <div className="flex">
          {/* Sidebar - Desktop */}
          <aside className={`
            hidden lg:block fixed left-0 top-16 h-[calc(100vh-4rem)]
            bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800
            transition-all duration-300 overflow-x-hidden overflow-y-auto
            ${isCollapsed ? 'w-20' : 'w-64'}
            z-40
          `}>
            <div className="h-full flex flex-col">
              
              {/* Toggle Button */}
              <div className="flex justify-center p-3">
                <button
                  onClick={() => setIsCollapsed(!isCollapsed)}
                  className={`flex items-center justify-center w-8 h-8 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors ${isCollapsed ? 'mx-auto' : 'ml-auto mr-3'}`}
                >
                  {isCollapsed ? (
                    <ChevronRight className="w-4 h-4 text-gray-500" />
                  ) : (
                    <ChevronLeft className="w-4 h-4 text-gray-500" />
                  )}
                </button>
              </div>

              {/* Navigation */}
              <nav className="flex-1 px-3 space-y-1 overflow-y-auto overflow-x-hidden">
                {NAV_ITEMS.map((item) => (
                  <NavItem
                    key={item.href}
                    item={item}
                    isActive={pathname === item.href}
                    isCollapsed={isCollapsed}
                    badgeOverride={item.href === '/dashboard/admin/verifications' ? pendingCount : undefined}
                  />
                ))}
              </nav>

              {/* Logout button only — profile is in the top nav */}
              <div className="p-3 border-t border-gray-200 dark:border-gray-800 flex justify-center">
                <button
                  onClick={handleLogout}
                  title="Logout"
                  className={`flex items-center gap-2 px-3 py-2 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors ${isCollapsed ? 'justify-center w-10' : 'w-full'}`}
                >
                  <LogOut className="w-4 h-4 flex-shrink-0" />
                  {!isCollapsed && <span className="text-sm font-medium">Logout</span>}
                </button>
              </div>
            </div>
          </aside>

          {/* Mobile Sidebar - Drawer */}
          {isMobileOpen && (
            <div className="lg:hidden fixed inset-0 z-50 flex">
              <div
                className="fixed inset-0 bg-black/50"
                onClick={() => setIsMobileOpen(false)}
              />
              <div className="relative w-64 bg-white dark:bg-gray-900 h-full overflow-y-auto">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="font-bold text-gray-900 dark:text-white">Admin Panel</h2>
                    <button
                      onClick={() => setIsMobileOpen(false)}
                      className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Navigation */}
                  <nav className="space-y-1">
                    {NAV_ITEMS.map((item) => (
                      <NavItem
                        key={item.href}
                        item={item}
                        isActive={pathname === item.href}
                        isCollapsed={false}
                        onClick={() => setIsMobileOpen(false)}
                        badgeOverride={item.href === '/dashboard/admin/verifications' ? pendingCount : undefined}
                      />
                    ))}
                  </nav>

                  {/* Logout */}
                  <button
                    onClick={handleLogout}
                    className="w-full mt-4 flex items-center gap-2 px-3 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="text-sm font-medium">Logout</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Main Content — offset by sidebar width on desktop */}
          <main className={`flex-1 min-w-0 transition-all duration-300 ${isCollapsed ? 'lg:ml-20' : 'lg:ml-64'}`}>
            {/* Mobile header bar with hamburger */}
            <div className="lg:hidden flex items-center gap-3 px-4 py-3 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 sticky top-14 z-30">
              <button
                onClick={() => setIsMobileOpen(true)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                aria-label="Open menu"
              >
                <Menu className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </button>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Admin Panel</span>
            </div>
            {children}
          </main>
        </div>
      </div>
    </PageLayout>
  )
}