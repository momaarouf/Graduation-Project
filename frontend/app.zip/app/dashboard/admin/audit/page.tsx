'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
  Activity, LogOut, Lock, Pause, CheckCircle, XCircle,
  Loader2, RefreshCw, ChevronLeft, ChevronRight, User, Shield, Clock
} from 'lucide-react'
import { useAuth } from '@/src/lib/contexts/AuthContext'
import { adminGetAuditEvents, AuditEventResponse } from '@/src/lib/api/admin'
import toast from 'react-hot-toast'

// ─── Action display helpers ───────────────────────────────────────────────────
const ACTION_META: Record<string, { label: string; color: string; bg: string }> = {
  USER_SUSPEND:              { label: 'User Suspended',         color: 'text-amber-600 dark:text-amber-400',   bg: 'bg-amber-50 dark:bg-amber-900/20'   },
  USER_ACTIVATE:             { label: 'User Activated',         color: 'text-green-600 dark:text-green-400',   bg: 'bg-green-50 dark:bg-green-900/20'   },
  USER_BAN:                  { label: 'User Banned',            color: 'text-red-600 dark:text-red-400',       bg: 'bg-red-50 dark:bg-red-900/20'       },
  USER_DEACTIVATE:           { label: 'User Deactivated',       color: 'text-slate-600 dark:text-slate-400',   bg: 'bg-slate-50 dark:bg-slate-800/50'   },
  USER_REACTIVATE:           { label: 'User Reactivated',       color: 'text-blue-600 dark:text-blue-400',     bg: 'bg-blue-50 dark:bg-blue-900/20'     },
  GUIDE_VERIFY_APPROVE:      { label: 'Guide Approved',         color: 'text-green-600 dark:text-green-400',   bg: 'bg-green-50 dark:bg-green-900/20'   },
  GUIDE_VERIFY_REJECT:       { label: 'Guide Rejected',         color: 'text-red-600 dark:text-red-400',       bg: 'bg-red-50 dark:bg-red-900/20'       },
  GUIDE_VERIFY_APPROVE_OVERRIDE: { label: 'Guide Override',     color: 'text-indigo-600 dark:text-indigo-400', bg: 'bg-indigo-50 dark:bg-indigo-900/20' },
}

function getActionMeta(action: string) {
  return ACTION_META[action] ?? {
    label: action.replace(/_/g, ' '),
    color: 'text-gray-600 dark:text-gray-400',
    bg: 'bg-gray-50 dark:bg-gray-800'
  }
}

function ActionIcon({ action }: { action: string }) {
  if (action.includes('SUSPEND')) return <Pause className="w-4 h-4" />
  if (action.includes('BAN')) return <Lock className="w-4 h-4" />
  if (action.includes('DEACTIVATE')) return <XCircle className="w-4 h-4" />
  if (action.includes('ACTIVATE') || action.includes('REACTIVATE')) return <CheckCircle className="w-4 h-4" />
  if (action.includes('APPROVE')) return <CheckCircle className="w-4 h-4" />
  if (action.includes('REJECT')) return <XCircle className="w-4 h-4" />
  return <Activity className="w-4 h-4" />
}

// ─── Details expander ─────────────────────────────────────────────────────────
function DetailsPanel({ json }: { json?: string }) {
  const [open, setOpen] = useState(false)
  if (!json) return null

  let parsed: Record<string, unknown> = {}
  try { parsed = JSON.parse(json) } catch { return null }

  const entries = Object.entries(parsed).filter(([, v]) => v != null && v !== '' && v !== false)
  if (entries.length === 0) return null

  return (
    <div className="mt-2">
      <button onClick={() => setOpen(o => !o)}
        className="text-xs text-blue-500 hover:text-blue-600 dark:text-blue-400">
        {open ? 'Hide details ▲' : 'Show details ▼'}
      </button>
      {open && (
        <div className="mt-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg text-xs font-mono space-y-1 border border-gray-100 dark:border-gray-700">
          {entries.map(([k, v]) => (
            <div key={k} className="flex gap-2">
              <span className="text-gray-500 dark:text-gray-400 flex-shrink-0">{k}:</span>
              <span className="text-gray-800 dark:text-gray-200 break-all">{String(v)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Filter Types ─────────────────────────────────────────────────────────────
type FilterCategory = 'all' | 'user' | 'guide' | 'auth'

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AdminAuditPage() {
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()

  const [events, setEvents] = useState<AuditEventResponse[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const [totalElements, setTotalElements] = useState(0)

  const [categoryFilter, setCategoryFilter] = useState<FilterCategory>('all')
  const [startDate, setStartDate] = useState(
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  )
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0])

  useEffect(() => {
    if (!authLoading && (!user || user.role !== 'Admin')) router.push('/dashboard')
  }, [user, authLoading, router])

  const loadEvents = useCallback(async (p: number = 0) => {
    setIsLoading(true)
    try {
      // Backend returns Spring Page<AdminAuditEventResponse>
      const result = await adminGetAuditEvents(p, 50)
      setEvents(result.content || [])
      setTotalPages(result.totalPages)
      setTotalElements(result.totalElements)
      setPage(result.number)
    } catch {
      toast.error('Failed to load audit events')
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => { loadEvents(0) }, [loadEvents])

  // Client-side filter (on top of server pagination)
  const filtered = events.filter(e => {
    const action = e.action.toUpperCase()

    // Category
    if (categoryFilter !== 'all') {
      if (categoryFilter === 'user' && !action.startsWith('USER_')) return false
      if (categoryFilter === 'guide' && !action.startsWith('GUIDE_')) return false
      if (categoryFilter === 'auth' && !['LOGIN','LOGOUT','REGISTER'].some(k => action.includes(k))) return false
    }

    // Date range
    const dt = new Date(e.createdAtUtc)
    if (startDate && dt < new Date(startDate + 'T00:00:00')) return false
    if (endDate && dt > new Date(endDate + 'T23:59:59')) return false

    return true
  })

  const uniqueAdmins = new Set(events.map(e => e.adminEmail).filter(Boolean)).size

  if (authLoading) return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
    </div>
  )

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gray-50 dark:bg-gray-950">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Activity className="w-6 h-6 text-purple-500" /> Audit Trail
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">All admin actions, newest first</p>
          </div>
          <button onClick={() => loadEvents(page)} disabled={isLoading}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition">
            <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Total events', value: totalElements },
            { label: 'This page', value: filtered.length },
            { label: 'Unique admins', value: uniqueAdmins },
            { label: 'Page', value: `${page + 1} / ${totalPages || 1}` },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
              <p className="text-xs text-gray-500 dark:text-gray-400">{s.label}</p>
              <p className="text-xl font-bold text-gray-900 dark:text-white mt-0.5">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1.5">Category</label>
              <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value as FilterCategory)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500">
                <option value="all">All Events</option>
                <option value="user">User Actions</option>
                <option value="guide">Guide Verifications</option>
                <option value="auth">Auth Events</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1.5">From</label>
              <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1.5">To</label>
              <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500" />
            </div>
          </div>
        </div>

        {/* Timeline */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-400">
            <Activity className="w-10 h-10 mb-3 opacity-40" />
            <p className="text-sm">No events for selected filters</p>
          </div>
        ) : (
          <div className="relative space-y-2">
            {/* Vertical line */}
            <div className="absolute left-[23px] top-0 bottom-0 w-px bg-gray-200 dark:bg-gray-800 pointer-events-none" />

            {filtered.map(event => {
              const meta = getActionMeta(event.action)
              return (
                <div key={event.id} className="flex gap-4 items-start">
                  {/* Icon */}
                  <div className={`relative z-10 w-12 h-12 rounded-full border-2 border-white dark:border-gray-950 flex items-center justify-center flex-shrink-0 ${meta.bg} ${meta.color}`}>
                    <ActionIcon action={event.action} />
                  </div>

                  {/* Card */}
                  <div className="flex-1 min-w-0 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4 mb-2">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-sm font-semibold ${meta.color}`}>{meta.label}</span>
                          <span className="text-xs text-gray-400 font-mono bg-gray-50 dark:bg-gray-800 px-1.5 py-0.5 rounded">{event.action}</span>
                        </div>
                        <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{event.summary}</p>

                        {/* Target */}
                        <div className="flex items-center gap-3 mt-2 text-xs text-gray-500 dark:text-gray-400 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Shield className="w-3 h-3" />
                            Target: <span className="font-mono">{event.targetType} #{event.targetId}</span>
                          </span>
                          {event.adminEmail && (
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              By: <span className="font-medium">{event.adminEmail}</span>
                            </span>
                          )}
                        </div>

                        <DetailsPanel json={event.detailsJson} />
                      </div>

                      {/* Timestamp */}
                      <div className="text-right text-xs text-gray-400 whitespace-nowrap flex-shrink-0">
                        <div className="flex items-center gap-1 justify-end">
                          <Clock className="w-3 h-3" />
                          {new Date(event.createdAtUtc).toLocaleDateString()}
                        </div>
                        <div>{new Date(event.createdAtUtc).toLocaleTimeString()}</div>
                        <div className="font-mono text-gray-300 dark:text-gray-600">#{event.id}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 pt-2">
            <button onClick={() => loadEvents(page - 1)} disabled={page === 0 || isLoading}
              className="p-2 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-40 transition">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm text-gray-600 dark:text-gray-400">
              Page {page + 1} of {totalPages}
            </span>
            <button onClick={() => loadEvents(page + 1)} disabled={page >= totalPages - 1 || isLoading}
              className="p-2 rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-40 transition">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  )
}