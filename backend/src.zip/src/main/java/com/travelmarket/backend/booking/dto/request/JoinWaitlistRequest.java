package com.travelmarket.backend.booking.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Request body for POST /api/traveler/waitlist.
 *
 * Traveler specifies which full occurrence they want to be queued for.
 * The service validates the occurrence is genuinely full before creating
 * the waitlist entry.
 */
@Data
public class JoinWaitlistRequest {

    /** The full occurrence the traveler wants to join the waitlist for. */
    @NotNull(message = "Occurrence ID is required")
    private Long occurrenceId;
}