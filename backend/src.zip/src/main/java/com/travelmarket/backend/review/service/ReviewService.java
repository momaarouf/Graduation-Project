package com.travelmarket.backend.review.service;

import com.travelmarket.backend.review.dto.ReviewCreateRequest;
import com.travelmarket.backend.review.dto.ReviewResponse;
import com.travelmarket.backend.review.dto.ReviewSummaryResponse;
import com.travelmarket.backend.review.entity.Review;
import com.travelmarket.backend.review.repository.ReviewRepository;

// ─────────────────────────────────────────────────────────────────────────────
// VERIFY THESE IMPORTS match your actual package structure before compiling.
// From the error log we know UserRepository is in .repository package.
// Adjust Booking / BookingStatus / TourOccurrence paths if yours differ.
// ─────────────────────────────────────────────────────────────────────────────
import com.travelmarket.backend.booking.entity.Booking;           // adjust if needed
import com.travelmarket.backend.booking.enums.BookingStatus;     // adjust if needed
import com.travelmarket.backend.tour.entity.TourOccurrence;    // adjust if needed
import com.travelmarket.backend.entity.User;              // adjust if needed
import com.travelmarket.backend.booking.repository.BookingRepository;      // adjust if needed
import com.travelmarket.backend.tour.repository.TourOccurrenceRepository; // adjust if needed
import com.travelmarket.backend.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository        reviewRepository;
    private final BookingRepository       bookingRepository;
    private final UserRepository          userRepository;
    private final TourOccurrenceRepository occurrenceRepository;

    // =========================================================================
    // CREATE REVIEW
    // =========================================================================

    /**
     * Create a review for a completed booking.
     *
     * Validation order (fail-fast):
     *   1. Booking exists                → 404
     *   2. Booking belongs to traveler   → 403  (ownership)
     *   3. Booking status == COMPLETED   → 400  (eligibility)
     *   4. No review exists yet          → 409  (duplicate)
     *
     * Guide/tour/occurrence IDs are denormalized from the booking so that
     * aggregation queries don't need to join through bookings every time.
     */
    @Transactional
    public ReviewResponse createReview(Long authenticatedTravelerId,
                                       ReviewCreateRequest request) {

        // ── 1. Booking exists ─────────────────────────────────────────────
        Booking booking = bookingRepository.findById(request.bookingId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Booking not found: " + request.bookingId()
                ));

        // ── 2. OWNERSHIP CHECK — traveler can only review their own booking ─
        // IMPORTANT: never trust the client for ownership — always use the JWT principal.
        if (!booking.getTravelerId().equals(authenticatedTravelerId)) {
            log.warn("Traveler {} attempted to review booking {} owned by {}",
                    authenticatedTravelerId, booking.getId(), booking.getTravelerId());
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "You cannot review another traveler's booking"
            );
        }

        // ── 3. ELIGIBILITY CHECK — booking must be COMPLETED ─────────────
        if (booking.getStatus() != BookingStatus.Completed) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only completed bookings can be reviewed. Current status: " + booking.getStatus()
            );
        }

        // ── 4. DUPLICATE CHECK — one review per booking ───────────────────
        // DB UNIQUE constraint on booking_id is the final safety net,
        // but we check here first to return a clean 409 instead of a DB error.
        if (reviewRepository.existsByBookingId(request.bookingId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "You have already reviewed this booking"
            );
        }

        // ── Build the Review entity ───────────────────────────────────────
        // Denormalize guideId, tourTemplateId, occurrenceId from the booking
        // so aggregation queries don't need to join through bookings.
        Review review = Review.builder()
                .bookingId(booking.getId())
                .travelerId(authenticatedTravelerId)
                .guideId(booking.getGuideId())                 // denormalized
                .tourTemplateId(booking.getTourTemplateId())   // denormalized
                .occurrenceId(booking.getOccurrenceId())       // denormalized
                .ratingOverall(request.ratingOverall().shortValue())
                .ratingGuide(request.ratingGuide().shortValue())
                .ratingTour(request.ratingTour().shortValue())
                .ratingValue(request.ratingValue().shortValue())
                .comment(request.comment())
                .build();
        // createdAt / updatedAt set by @PrePersist in Review entity

        Review saved = reviewRepository.save(review);
        log.info("Review {} created by traveler {} for booking {}",
                saved.getId(), authenticatedTravelerId, booking.getId());

        // ── Map to response ───────────────────────────────────────────────
        return toResponse(saved);
    }

    // =========================================================================
    // TRAVELER: MY REVIEWS
    // =========================================================================

    /**
     * Returns all reviews written by the authenticated traveler, newest first.
     * Includes hidden reviews — the traveler should always see their own.
     */
    @Transactional(readOnly = true)
    public Page<ReviewResponse> getMyReviews(Long travelerId, Pageable pageable) {
        return reviewRepository
                .findByTravelerIdOrderByCreatedAtDesc(travelerId, pageable)
                .map(this::toResponse);
    }

    // =========================================================================
    // PUBLIC: REVIEWS FOR A GUIDE
    // =========================================================================

    /**
     * Returns aggregated stats + paginated visible reviews for a guide.
     * Hidden reviews are excluded from all public responses.
     */
    @Transactional(readOnly = true)
    public ReviewSummaryResponse getReviewsForGuide(Long guideId, Pageable pageable) {

        Page<ReviewResponse> reviews = reviewRepository
                .findByGuideIdAndHiddenFalseOrderByCreatedAtDesc(guideId, pageable)
                .map(this::toResponse);

        Double avgOverall = reviewRepository.findAverageOverallRatingByGuideId(guideId);
        Long   total      = reviewRepository.countVisibleReviewsByGuideId(guideId);

        // Sub-rating averages — computed inline from the page for efficiency.
        // For large datasets, add dedicated JPQL queries in ReviewRepository.
        List<Object[]> dist = reviewRepository.findRatingDistributionByGuideId(guideId);

        return buildSummary(avgOverall, total, dist, reviews);
    }

    // =========================================================================
    // PUBLIC: REVIEWS FOR A TOUR TEMPLATE
    // =========================================================================

    /**
     * Returns aggregated stats + paginated visible reviews for a tour template.
     * Hidden reviews are excluded from all public responses.
     */
    @Transactional(readOnly = true)
    public ReviewSummaryResponse getReviewsForTour(Long tourTemplateId, Pageable pageable) {

        Page<ReviewResponse> reviews = reviewRepository
                .findByTourTemplateIdAndHiddenFalseOrderByCreatedAtDesc(tourTemplateId, pageable)
                .map(this::toResponse);

        Double avgOverall = reviewRepository.findAverageOverallRatingByTourTemplateId(tourTemplateId);
        Long   total      = reviewRepository.countVisibleReviewsByTourTemplateId(tourTemplateId);

        List<Object[]> dist = reviewRepository.findRatingDistributionByTourTemplateId(tourTemplateId);

        return buildSummary(avgOverall, total, dist, reviews);
    }

    // =========================================================================
    // PRIVATE HELPERS
    // =========================================================================

    /**
     * Map a Review entity → ReviewResponse DTO.
     *
     * Enriches with:
     *   - travelerName + travelerAvatarUrl  (from User entity)
     *   - tourTitle                         (from TourOccurrence → TourTemplate)
     *   - tourDate                          (occurrence startTimeUtc)
     *
     * These are separate queries per review. At current review volumes this is
     * fine. If it becomes a bottleneck, add a JOIN fetch query in the repository.
     */
    private ReviewResponse toResponse(Review review) {

        // Traveler display info (name + avatar — no PII exposed)
        String travelerName      = "Traveler";
        String travelerAvatarUrl = null;
        try {
            User traveler    = userRepository.findById(review.getTravelerId()).orElseThrow();
            travelerName     = traveler.getFullName();   // adjust getter if your field differs
            travelerAvatarUrl = traveler.getAvatarUrl(); // adjust getter if your field differs
        } catch (Exception e) {
            log.warn("Could not load traveler {} for review {}", review.getTravelerId(), review.getId());
        }

        // Tour title + tour date (occurrence start time)
        String tourTitle = "Tour";
        java.time.Instant tourDate = review.getCreatedAt(); // fallback
        try {
            TourOccurrence occurrence = occurrenceRepository.findById(review.getOccurrenceId()).orElseThrow();
            tourDate  = occurrence.getStartTimeUtc();        // adjust getter if your field differs
            tourTitle = occurrence.getTourTemplate().getTitle(); // adjust if your relationship differs
        } catch (Exception e) {
            log.warn("Could not load occurrence {} for review {}", review.getOccurrenceId(), review.getId());
        }

        return new ReviewResponse(
                review.getId(),
                review.getBookingId(),
                review.getTourTemplateId(),
                review.getOccurrenceId(),

                // Cast Short → Integer for the DTO (DTO uses Integer for cleaner JSON)
                (int) review.getRatingOverall(),
                (int) review.getRatingGuide(),
                (int) review.getRatingTour(),
                (int) review.getRatingValue(),

                review.getComment(),

                review.getTravelerId(),
                travelerName,
                travelerAvatarUrl,

                tourTitle,
                tourDate,

                review.getGuideReply(),
                review.getGuideRepliedAt(),

                review.getCreatedAt()
        );
    }

    /**
     * Assemble a ReviewSummaryResponse from pre-computed aggregates.
     * Extracted to avoid duplication between getReviewsForGuide and getReviewsForTour.
     */
    private ReviewSummaryResponse buildSummary(Double avgOverall,
                                               Long total,
                                               List<Object[]> distributionRows,
                                               Page<ReviewResponse> reviews) {

        ReviewSummaryResponse.Distribution dist = total == 0
                ? ReviewSummaryResponse.Distribution.empty()
                : ReviewSummaryResponse.Distribution.from(distributionRows);

        // Sub-rating averages — derived from current page for simplicity.
        // Replace with dedicated repository queries if you need precise pagination-independent values.
        double avgGuide = reviews.getContent().stream()
                .mapToInt(ReviewResponse::ratingGuide).average().orElse(0.0);
        double avgTour  = reviews.getContent().stream()
                .mapToInt(ReviewResponse::ratingTour).average().orElse(0.0);
        double avgValue = reviews.getContent().stream()
                .mapToInt(ReviewResponse::ratingValue).average().orElse(0.0);

        return new ReviewSummaryResponse(
                avgOverall,
                avgGuide,
                avgTour,
                avgValue,
                total != null ? total : 0L,
                dist,
                reviews
        );
    }
}